"""
Main Application - Redesigned with New Dashboard
Integrates authentication, upload, and advanced RFM analytics
"""

from dash import Dash, dcc, html, Input, Output, State, callback_context, clientside_callback
import dash_bootstrap_components as dbc
import logging
import time
import os

from auth import render_login_page, register_auth_callbacks
from upload import render_upload_page, register_upload_callbacks
from dashboard import render_new_dashboard, register_new_dashboard_callbacks

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s:%(name)s:%(message)s'
)
logger = logging.getLogger(__name__)

# =============================================
# DASH APP INITIALIZATION
# =============================================

# Create assets folder if it doesn't exist
assets_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets')
os.makedirs(assets_folder, exist_ok=True)

app = Dash(__name__, suppress_callback_exceptions=True, external_stylesheets=[dbc.themes.BOOTSTRAP], assets_folder=assets_folder)
app.title = "RFM Analytics Platform"

# =============================================
# CUSTOM ROUTES FOR HTML FILES
# =============================================

# Get the directory where HTML files are located
html_files_dir = os.path.dirname(os.path.abspath(__file__))

# =============================================
# APP LAYOUT
# =============================================

app.layout = html.Div([
    # Header (fixed at top)
    html.Div(id='main-header', style={
        'backgroundColor': '#667eea',
        'padding': '15px 20px',
        'color': 'white',
        'textAlign': 'center',
        'fontSize': '24px',
        'fontWeight': 'bold',
        'display': 'none'
    }),
    
    # Main content
    html.Div(id='main-content', style={
        'padding': '20px',
        'backgroundColor': '#f5f5f5',
        'minHeight': '100vh'
    }, children=render_login_page({'logged_in': False, 'username': '', 'show_register': False})),
    
    # Data stores
    dcc.Store(id='login-store', data={'logged_in': False, 'username': '', 'show_register': False}, storage_type='memory'),
    dcc.Store(id='user-profile-store', data={'email': '', 'company': '', 'industry': ''}),
    dcc.Store(id='data-uploaded-store', data={'uploaded': False, 'filename': '', 'row_count': 0}, storage_type='local'),
    dcc.Store(id='data-store', data={'tx_count': 0, 'rfm_count': 0, 'tx_json': None, 'rfm_json': None}),
    dcc.Store(id='toast-store', data={'message': '', 'type': 'error', 'timestamp': 0}),
    
    # Global toast notification container
    html.Div(id='global-toast', style={
        'position': 'fixed',
        'top': '20px',
        'right': '20px',
        'minWidth': '300px',
        'zIndex': '9999',
        'display': 'none'
    }),
    
    # Auto-clear toast after 3 seconds
    dcc.Interval(id='toast-timer', interval=3000, n_intervals=0),
])

# =============================================
# ROUTER CALLBACK - Main Navigation Logic
# =============================================

@app.callback(
    Output('main-content', 'children'),
    Input('login-store', 'data'),
    Input('data-uploaded-store', 'data'),
    prevent_initial_call=False
)
def render_content(login_data, upload_data):
    """Route between login, upload, and dashboard pages."""
    try:
        logger.info(f"[ROUTER] Navigation check")
        logger.info(f"[ROUTER]   login_data={login_data}")
        logger.info(f"[ROUTER]   upload_data={upload_data}")
        
        # If not logged in, show login page
        if not login_data or not login_data.get('logged_in'):
            logger.info("[ROUTER] -> Rendering LOGIN page")
            return render_login_page(login_data or {'logged_in': False, 'username': '', 'show_register': False})
        
        # If logged in but data not uploaded, show upload page
        if not upload_data or not upload_data.get('uploaded'):
            logger.info("[ROUTER] -> Rendering UPLOAD page")
            return render_upload_page()
        
        # If logged in and data uploaded, show dashboard
        logger.info("[ROUTER] -> Rendering DASHBOARD page")
        return render_new_dashboard()
    
    except Exception as e:
        logger.error(f"[ROUTER] Error in render_content: {e}", exc_info=True)
        return html.Div(f"Error: {str(e)}", style={'padding': '20px', 'color': 'red'})

# =============================================
# REGISTER ALL CALLBACKS
# =============================================

logger.info("[INIT] Registering auth callbacks...")
register_auth_callbacks(app)

logger.info("[INIT] Registering upload callbacks...")
register_upload_callbacks(app)

logger.info("[INIT] Registering dashboard callbacks...")
register_new_dashboard_callbacks(
    app,
    load_data=None,  # Not needed anymore, handled in upload.py
    preprocess=None,  # Not needed
    compute_rfm_with_log_transform=None,  # Not needed  
    scale_rfm_features=None,  # Not needed
    perform_kmeans_clustering=None  # Not needed
)

# =============================================
# GLOBAL TOAST CALLBACK - Display error/success messages
# =============================================

@app.callback(
    Output('toast-store', 'data'),
    Input('toast-timer', 'n_intervals'),
    State('toast-store', 'data'),
    prevent_initial_call=True
)
def auto_clear_toast(n_intervals, toast_data):
    """Auto-clear toast after 3 seconds."""
    if toast_data and toast_data.get('message'):
        # Check if toast is older than 3 seconds
        current_time = time.time() * 1000
        toast_time = toast_data.get('timestamp', 0)
        if current_time - toast_time > 3000:
            return {'message': '', 'type': 'error', 'timestamp': 0}
    return toast_data

@app.callback(
    Output('global-toast', 'children'),
    Output('global-toast', 'style'),
    Input('toast-store', 'data'),
    prevent_initial_call=True
)
def display_global_toast(toast_data):
    """Display toast notification from toast-store."""
    if not toast_data or not toast_data.get('message'):
        return '', {'position': 'fixed', 'top': '20px', 'right': '20px', 'minWidth': '300px', 'zIndex': '9999', 'display': 'none'}
    
    msg = toast_data.get('message', '')
    msg_type = toast_data.get('type', 'error')
    
    # Color based on type
    if msg_type == 'success':
        bg_color = '#4caf50'
        border_color = '#2e7d32'
    else:
        bg_color = '#f44336'
        border_color = '#c62828'
    
    toast_element = html.Div([
        html.Div([
            html.Div([
                html.Span('✓' if msg_type == 'success' else '✕', 
                         style={'fontSize': '20px', 'marginRight': '10px', 'fontWeight': 'bold'}),
                html.Span(msg, style={'fontSize': '14px'})
            ], style={'display': 'flex', 'alignItems': 'center'})
        ], style={
            'backgroundColor': bg_color,
            'color': 'white',
            'padding': '15px 20px',
            'borderRadius': '4px',
            'boxShadow': '0 2px 8px rgba(0,0,0,0.2)',
            'borderLeft': f'4px solid {border_color}'
        })
    ], style={
        'animation': 'slideIn 0.3s ease-in-out'
    })
    
    style = {
        'position': 'fixed',
        'top': '20px',
        'right': '20px',
        'minWidth': '300px',
        'zIndex': '9999',
        'display': 'block'
    }
    
    return toast_element, style

# =============================================
# RUN APPLICATION
# =============================================

if __name__ == '__main__':
    logger.info("[APP] Starting E-Commerce RFM Analytics Platform")
    logger.info("[APP] Access at http://127.0.0.1:8051")
    app.run(port=8051, debug=False)
