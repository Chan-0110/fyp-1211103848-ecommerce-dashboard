"""
User Authentication Module
Handles login and registration pages
"""

import json
import os
import logging
from dash import html, dcc, Input, Output, State, callback_context, clientside_callback
import time
from werkzeug.security import generate_password_hash, check_password_hash

logger = logging.getLogger(__name__)

USERS_FILE = 'users_database.json'

# =============================================
# USER AUTHENTICATION FUNCTIONS
# =============================================

def load_users():
    """Load registered users from file."""
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_users(users_dict):
    """Save users to file."""
    with open(USERS_FILE, 'w') as f:
        json.dump(users_dict, f)

def verify_user(username, password):
    """Verify login credentials using secure password hash comparison."""
    users = load_users()
    if username not in users:
        logger.warning(f"[AUTH] Login attempt with non-existent username: {username}")
        return False
    
    user_data = users[username]
    
    # Support both old plaintext and new hashed password formats
    if isinstance(user_data, dict):
        # New format: user data is a dictionary with password_hash
        stored_hash = user_data.get('password_hash')
        if not stored_hash:
            logger.error(f"[AUTH] User {username} has invalid password_hash format")
            return False
        is_valid = check_password_hash(stored_hash, password)
    else:
        # Old format: user data is just a plaintext password string (backward compatibility)
        logger.info(f"[AUTH] User {username} using legacy plaintext password - upgrading on next login...")
        is_valid = (user_data == password)
        
        # Upgrade user to hashed format if login is successful
        if is_valid:
            new_hash = generate_password_hash(password, method='pbkdf2:sha256')
            users[username] = {
                'password_hash': new_hash,
                'email': 'legacy@user.local',
                'company': 'N/A',
                'industry': 'N/A'
            }
            save_users(users)
            logger.info(f"[AUTH] ✅ Upgraded user {username} to secure hash format")
    
    logger.info(f"[AUTH] Login verification for {username}: {'✅ PASS' if is_valid else '❌ FAIL'}")
    return is_valid

# =============================================
# AUTH PAGE RENDERING FUNCTIONS
# =============================================

def render_login_form():
    """Render login form using Input element as trigger."""
    return html.Div([
        html.Div([
            html.H2('🔐 User Authentication', style={'color': '#667eea', 'textAlign': 'center', 'marginTop': '0', 'marginBottom': '30px', 'fontSize': '28px'}),
            
            html.Div([
                html.Label('Username:', style={'fontWeight': 'bold', 'marginBottom': '8px', 'display': 'block', 'color': '#333'}),
                dcc.Input(
                    id='username-input',
                    type='text',
                    placeholder='Enter your username',
                    style={
                        'width': '100%', 'padding': '12px', 'marginBottom': '20px', 'border': '1px solid #ddd',
                        'borderRadius': '4px', 'fontSize': '14px', 'boxSizing': 'border-box'
                    }
                ),
            ]),
            
            html.Div([
                html.Label('Password:', style={'fontWeight': 'bold', 'marginBottom': '8px', 'display': 'block', 'color': '#333'}),
                dcc.Input(
                    id='password-input',
                    type='password',
                    placeholder='Enter your password',
                    style={
                        'width': '100%', 'padding': '12px', 'marginBottom': '20px', 'border': '1px solid #ddd',
                        'borderRadius': '4px', 'fontSize': '14px', 'boxSizing': 'border-box'
                    }
                ),
            ]),
            
            html.Button(
                'Login',
                id='login-btn',
                n_clicks=0,
                style={
                    'width': '100%',
                    'padding': '12px',
                    'backgroundColor': '#667eea',
                    'color': 'white',
                    'border': 'none',
                    'borderRadius': '4px',
                    'fontSize': '16px',
                    'fontWeight': 'bold',
                    'cursor': 'pointer',
                    'marginBottom': '15px'
                }
            ),
            
            # Toast notification - below login button
            html.Div(id='login-toast', style={
                'padding': '12px 16px',
                'borderRadius': '6px',
                'marginBottom': '15px',
                'display': 'none',
                'fontWeight': 'bold',
                'fontSize': '14px',
                'textAlign': 'center'
            }),
            
            html.Div(id='login-error', style={'display': 'none'}, children=''),
            
            html.Div([
                html.Span("Don't have an account? ", style={'color': '#666', 'fontSize': '14px'}),
                html.Button(
                    'Register here',
                    id='switch-to-register-btn',
                    n_clicks=0,
                    style={
                        'backgroundColor': 'transparent',
                        'color': '#667eea',
                        'border': 'none',
                        'cursor': 'pointer',
                        'fontSize': '14px',
                        'fontWeight': 'bold',
                        'textDecoration': 'underline',
                        'padding': '0'
                    }
                )
            ], style={'textAlign': 'center'})
        ], style={
            'width': '350px',
            'margin': '100px auto',
            'padding': '40px',
            'backgroundColor': 'white',
            'borderRadius': '8px',
            'boxShadow': '0 4px 15px rgba(0,0,0,0.15)'
        })
    ], style={'backgroundColor': '#f5f5f5', 'minHeight': '100vh', 'display': 'flex', 'alignItems': 'center', 'justifyContent': 'center'})


def render_register_form():
    """Render registration form with user profile information."""
    return html.Div([
        html.Div([
            html.H2('📝 Register Page', style={'color': '#667eea', 'textAlign': 'center', 'marginTop': '0', 'marginBottom': '30px', 'fontSize': '28px'}),
            
            html.Div([
                html.Label('Username:', style={'fontWeight': 'bold', 'marginBottom': '8px', 'display': 'block'}),
                dcc.Input(id='register-username-input', type='text', placeholder='Min 3 characters', style={'width': '100%', 'padding': '10px', 'marginBottom': '15px', 'border': '1px solid #ddd', 'borderRadius': '4px', 'boxSizing': 'border-box'}),
            ]),
            
            html.Div([
                html.Label('Password:', style={'fontWeight': 'bold', 'marginBottom': '8px', 'display': 'block'}),
                dcc.Input(id='register-password-input', type='password', placeholder='Min 4 characters', style={'width': '100%', 'padding': '10px', 'marginBottom': '15px', 'border': '1px solid #ddd', 'borderRadius': '4px', 'boxSizing': 'border-box'}),
            ]),
            
            html.Div([
                html.Label('Email:', style={'fontWeight': 'bold', 'marginBottom': '8px', 'display': 'block'}),
                dcc.Input(id='register-email-input', type='email', placeholder='your@email.com', style={'width': '100%', 'padding': '10px', 'marginBottom': '15px', 'border': '1px solid #ddd', 'borderRadius': '4px', 'boxSizing': 'border-box'}),
            ]),
            
            html.Div([
                html.Label('Company (Optional):', style={'fontWeight': 'bold', 'marginBottom': '8px', 'display': 'block'}),
                dcc.Input(id='register-company-input', type='text', placeholder='Your company', style={'width': '100%', 'padding': '10px', 'marginBottom': '15px', 'border': '1px solid #ddd', 'borderRadius': '4px', 'boxSizing': 'border-box'}),
            ]),
            
            html.Div([
                html.Label('Industry (Optional):', style={'fontWeight': 'bold', 'marginBottom': '8px', 'display': 'block'}),
                dcc.Dropdown(
                    id='register-industry-input',
                    options=[
                        {'label': 'Select Industry', 'value': ''},
                        {'label': 'Retail', 'value': 'Retail'},
                        {'label': 'E-Commerce', 'value': 'E-Commerce'},
                        {'label': 'Manufacturing', 'value': 'Manufacturing'},
                        {'label': 'Technology', 'value': 'Technology'},
                        {'label': 'Finance', 'value': 'Finance'},
                        {'label': 'Healthcare', 'value': 'Healthcare'},
                        {'label': 'Education', 'value': 'Education'},
                        {'label': 'Logistics', 'value': 'Logistics'},
                        {'label': 'Hospitality', 'value': 'Hospitality'},
                        {'label': 'Other', 'value': 'Other'}
                    ],
                    value='',
                    style={'width': '100%', 'padding': '10px', 'marginBottom': '15px', 'border': '1px solid #ddd', 'borderRadius': '4px'}
                ),
            ]),
            
            html.Button(
                'Register',
                id='register-submit-btn',
                n_clicks=0,
                style={
                    'width': '100%', 'padding': '12px', 'backgroundColor': '#667eea', 'color': 'white',
                    'border': 'none', 'borderRadius': '4px', 'fontSize': '16px', 'fontWeight': 'bold',
                    'cursor': 'pointer', 'marginBottom': '15px'
                }
            ),
            
            # Toast notification - below register button
            html.Div(id='register-toast', style={
                'padding': '12px 16px',
                'borderRadius': '6px',
                'marginBottom': '15px',
                'display': 'none',
                'fontWeight': 'bold',
                'fontSize': '14px',
                'textAlign': 'center'
            }),
            
            html.Div(id='register-error', style={'display': 'none'}, children=''),
            
            html.Div([
                html.Span('Already have an account? ', style={'color': '#666', 'fontSize': '14px'}),
                html.Button(
                    'Login here',
                    id='switch-to-login-btn',
                    n_clicks=0,
                    style={
                        'backgroundColor': 'transparent', 'color': '#667eea', 'border': 'none',
                        'cursor': 'pointer', 'fontSize': '14px', 'fontWeight': 'bold', 'textDecoration': 'underline', 'padding': '0'
                    }
                )
            ], style={'textAlign': 'center'})
        ], style={
            'width': '400px', 'margin': '50px auto', 'padding': '40px', 'backgroundColor': 'white',
            'borderRadius': '8px', 'boxShadow': '0 4px 15px rgba(0,0,0,0.15)'
        })
    ], style={'backgroundColor': '#f5f5f5', 'minHeight': '100vh', 'display': 'flex', 'alignItems': 'center', 'justifyContent': 'center'})


def render_login_page(login_data):
    """Render login page with option to switch to register."""
    show_register = login_data and login_data.get('show_register', False)
    
    if show_register:
        return render_register_form()
    else:
        return render_login_form()


# =============================================
# CALLBACK REGISTRATION FUNCTION
# =============================================

def register_auth_callbacks(app):
    """Register authentication callbacks - Define all callbacks at module level below."""
    logger.info("[AUTH] Authentication callbacks registered")

# =============================================
# AUTH CALLBACKS - Module Level Definitions
# =============================================

# This app instance will be set by calling register_auth_callbacks
_app_instance = None

def _set_app(app):
    """Set the app instance for callbacks."""
    global _app_instance
    _app_instance = app

def register_auth_callbacks_impl(app):
    """Actually register the callbacks."""
    
    @app.callback(
        Output('login-store', 'data', allow_duplicate=True),
        Input('switch-to-register-btn', 'n_clicks'),
        State('login-store', 'data'),
        prevent_initial_call=True
    )
    def switch_to_register(n_clicks, login_data):
        """Switch to register form."""
        logger.info(f"[AUTH] switch_to_register: n_clicks={n_clicks}")
        return {'logged_in': False, 'username': '', 'show_register': True}

    @app.callback(
        Output('login-store', 'data', allow_duplicate=True),
        Input('switch-to-login-btn', 'n_clicks'),
        State('login-store', 'data'),
        prevent_initial_call=True
    )
    def switch_to_login(n_clicks, login_data):
        """Switch to login form."""
        logger.info(f"[AUTH] switch_to_login: n_clicks={n_clicks}")
        return {'logged_in': False, 'username': '', 'show_register': False}

    @app.callback(
        Output('login-store', 'data', allow_duplicate=True),
        Output('data-uploaded-store', 'data', allow_duplicate=True),
        Output('toast-store', 'data', allow_duplicate=True),
        Input('login-btn', 'n_clicks'),
        Input('password-input', 'n_submit'),
        State('username-input', 'value'),
        State('password-input', 'value'),
        State('login-store', 'data'),
        prevent_initial_call=True
    )
    def handle_login(n_clicks, n_submit, username, password, login_data):
        """Handle login when login button is clicked or Enter key pressed."""
        logger.info(f"[LOGIN] Callback fired: n_clicks={n_clicks}, n_submit={n_submit}, username={username}")
        
        # Trigger on button click OR Enter key press in password field
        if (not n_clicks or n_clicks == 0) and (not n_submit or n_submit == 0):
            logger.info(f"[LOGIN] No clicks yet")
            return login_data, {'uploaded': False, 'filename': '', 'row_count': 0}, {'message': '', 'type': 'error', 'timestamp': 0}
            
        try:
            logger.info(f"[LOGIN] Processing: username={username}, has_pwd={bool(password)}")
            
            if not username or not password:
                msg = 'Please enter both username and password'
                timestamp = time.time() * 1000
                logger.info(f"[LOGIN] Missing credentials")
                return {'logged_in': False, 'username': '', 'show_register': False}, {'uploaded': False, 'filename': '', 'row_count': 0}, {'message': msg, 'type': 'error', 'timestamp': timestamp}
            
            if verify_user(username, password):
                logger.info(f"[LOGIN] Success for {username}")
                msg = 'Login successful!'
                timestamp = time.time() * 1000
                return {'logged_in': True, 'username': username, 'show_register': False}, {'uploaded': False, 'filename': '', 'row_count': 0}, {'message': msg, 'type': 'success', 'timestamp': timestamp}
            else:
                logger.info(f"[LOGIN] Failed - wrong credentials")
                msg = 'Wrong username or password'
                timestamp = time.time() * 1000
                return {'logged_in': False, 'username': '', 'show_register': False}, {'uploaded': False, 'filename': '', 'row_count': 0}, {'message': msg, 'type': 'error', 'timestamp': timestamp}
        except Exception as e:
            logger.error(f"[LOGIN] Exception: {e}", exc_info=True)
            msg = f'Error: {str(e)}'
            timestamp = time.time() * 1000
            return login_data, {'uploaded': False, 'filename': '', 'row_count': 0}, {'message': msg, 'type': 'error', 'timestamp': timestamp}

    @app.callback(
        Output('register-toast', 'children', allow_duplicate=True),
        Output('register-toast', 'style', allow_duplicate=True),
        Output('register-error', 'children', allow_duplicate=True),
        Output('register-error', 'style', allow_duplicate=True),
        Output('login-store', 'data', allow_duplicate=True),
        Output('user-profile-store', 'data'),
        Input('register-submit-btn', 'n_clicks'),
        State('register-username-input', 'value'),
        State('register-password-input', 'value'),
        State('register-email-input', 'value'),
        State('register-company-input', 'value'),
        State('register-industry-input', 'value'),
        State('login-store', 'data'),
        prevent_initial_call=True
    )
    def handle_register(n_clicks, username, password, email, company, industry, login_data):
        """Handle registration."""
        logger.info(f"[REGISTER] Callback fired: n_clicks={n_clicks}, username={username}")
        
        if not n_clicks or n_clicks == 0:
            return '', {'display': 'none'}, '', {'display': 'none'}, login_data, {'email': '', 'company': '', 'industry': ''}
            
        try:
            logger.info(f"[REGISTER] Processing: username={username}")
            
            # Check for missing required fields
            if not username or len(username) < 3:
                msg = '❌ Username must be at least 3 characters'
                error_style = {
                    'padding': '12px 16px',
                    'borderRadius': '6px',
                    'marginBottom': '15px',
                    'display': 'block',
                    'fontWeight': 'bold',
                    'fontSize': '14px',
                    'textAlign': 'center',
                    'backgroundColor': '#ffebee',
                    'color': '#c62828',
                    'border': '1px solid #ef5350'
                }
                logger.info(f"[REGISTER] Validation failed: username too short")
                return '', {'display': 'none'}, msg, error_style, login_data, {'email': '', 'company': '', 'industry': ''}
            
            if not password or len(password) < 4:
                msg = '❌ Password must be at least 4 characters'
                error_style = {
                    'padding': '12px 16px',
                    'borderRadius': '6px',
                    'marginBottom': '15px',
                    'display': 'block',
                    'fontWeight': 'bold',
                    'fontSize': '14px',
                    'textAlign': 'center',
                    'backgroundColor': '#ffebee',
                    'color': '#c62828',
                    'border': '1px solid #ef5350'
                }
                logger.info(f"[REGISTER] Validation failed: password too short")
                return '', {'display': 'none'}, msg, error_style, login_data, {'email': '', 'company': '', 'industry': ''}
            
            if not email or '@' not in email:
                msg = '❌ Please enter a valid email'
                error_style = {
                    'padding': '12px 16px',
                    'borderRadius': '6px',
                    'marginBottom': '15px',
                    'display': 'block',
                    'fontWeight': 'bold',
                    'fontSize': '14px',
                    'textAlign': 'center',
                    'backgroundColor': '#ffebee',
                    'color': '#c62828',
                    'border': '1px solid #ef5350'
                }
                logger.info(f"[REGISTER] Validation failed: invalid email")
                return '', {'display': 'none'}, msg, error_style, login_data, {'email': '', 'company': '', 'industry': ''}
            
            users = load_users()
            
            if username in users:
                msg = '❌ Username already exists'
                error_style = {
                    'padding': '12px 16px',
                    'borderRadius': '6px',
                    'marginBottom': '15px',
                    'display': 'block',
                    'fontWeight': 'bold',
                    'fontSize': '14px',
                    'textAlign': 'center',
                    'backgroundColor': '#ffebee',
                    'color': '#c62828',
                    'border': '1px solid #ef5350'
                }
                logger.info(f"[REGISTER] Username {username} already exists")
                return '', {'display': 'none'}, msg, error_style, login_data, {'email': '', 'company': '', 'industry': ''}
            
            # 🔐 Hash password before storing
            password_hash = generate_password_hash(password, method='pbkdf2:sha256')
            users[username] = {
                'password_hash': password_hash,
                'email': email,
                'company': company or 'N/A',
                'industry': industry or 'N/A'
            }
            save_users(users)
            logger.info(f"[REGISTER] ✅ Registered: {username} (password hashed with pbkdf2:sha256)")
            
            user_profile = {
                'username': username,
                'email': email,
                'company': company or 'N/A',
                'industry': industry or 'N/A'
            }
            
            success_msg = '✅ Registration successful! Redirecting to upload page...'
            success_style = {
                'padding': '12px 16px',
                'borderRadius': '6px',
                'marginBottom': '15px',
                'display': 'block',
                'fontWeight': 'bold',
                'fontSize': '14px',
                'textAlign': 'center',
                'backgroundColor': '#e8f5e9',
                'color': '#2e7d32',
                'border': '1px solid #4caf50'
            }
            
            # Set logged_in to True and set data-uploaded-store to True to trigger navigation
            return success_msg, success_style, '', {'display': 'none'}, {
                'logged_in': True,
                'username': username,
                'show_register': False
            }, user_profile
            
        except Exception as e:
            logger.error(f"[REGISTER] Exception: {e}", exc_info=True)
            msg = f'❌ Error: {str(e)}'
            error_style = {
                'padding': '12px 16px',
                'borderRadius': '6px',
                'marginBottom': '15px',
                'display': 'block',
                'fontWeight': 'bold',
                'fontSize': '14px',
                'textAlign': 'center',
                'backgroundColor': '#ffebee',
                'color': '#c62828',
                'border': '1px solid #ef5350'
            }
            return '', {'display': 'none'}, msg, error_style, login_data, {'email': '', 'company': '', 'industry': ''}

# Override register_auth_callbacks to call the implementation
register_auth_callbacks = register_auth_callbacks_impl
