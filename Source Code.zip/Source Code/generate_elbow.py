"""
Elbow Method Analysis Generator
Loads Online Retail dataset, performs RFM analysis with log transformation,
and generates an elbow plot for K-means clustering (K=2 to 10).
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import timedelta
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
import logging
import os
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s: %(message)s'
)
logger = logging.getLogger(__name__)

# =============================================
# COLUMN STANDARDIZATION MAPPING
# =============================================

COLUMN_MAPPING = {
    'InvoiceDate': ['InvoiceDate', 'Date', 'date', 'order_date', 'OrderDate', 'time'],
    'Quantity': ['Quantity', 'Qty', 'qty', 'Count', 'count', 'OrderQty'],
    'UnitPrice': ['UnitPrice', 'Price', 'price', 'Rate', 'rate', 'Amount', 'amount'],
    'CustomerID': ['CustomerID', 'User_ID', 'user_id', 'Client_ID', 'ID', 'id'],
    'Description': ['Description', 'Product', 'product', 'Item', 'item_name', 'Desc'],
    'InvoiceNo': ['InvoiceNo', 'Order_ID', 'order_id', 'Transaction_ID', 'InvoiceID']
}

# =============================================
# DATA CLEANING FUNCTIONS
# =============================================

def standardize_column_names(df):
    """
    Standardize column names by mapping common variations to standard names.
    """
    df_copy = df.copy()
    applied_mappings = {}
    
    # Create a lowercase column mapping for case-insensitive matching
    lowercase_to_original = {col.lower(): col for col in df_copy.columns}
    
    # Try to map each standard column
    for standard_name, variations in COLUMN_MAPPING.items():
        # Skip if already has the standard name
        if standard_name in df_copy.columns:
            continue
        
        # Try each variation (case-insensitive)
        found_match = False
        for variation in variations:
            variation_lower = variation.lower()
            
            # Check if this variation exists (case-insensitive)
            if variation_lower in lowercase_to_original:
                original_col = lowercase_to_original[variation_lower]
                df_copy.rename(columns={original_col: standard_name}, inplace=True)
                applied_mappings[original_col] = standard_name
                logger.info(f"Renamed '{original_col}' → '{standard_name}'")
                found_match = True
                break
    
    return df_copy, applied_mappings

def validate_required_columns(df):
    """
    Validate that all required columns are present.
    """
    required_columns = ['CustomerID', 'InvoiceDate', 'Quantity', 'UnitPrice']
    missing_columns = [col for col in required_columns if col not in df.columns]
    
    if missing_columns:
        available_columns = list(df.columns)
        error_msg = (
            f"Missing required columns: {', '.join(missing_columns)}\n"
            f"Available columns: {', '.join(available_columns)}\n"
        )
        logger.error(error_msg)
        raise ValueError(error_msg)

def load_and_clean_data(file_path):
    """
    Load data file (supports .xlsx, .csv, .xls) and perform initial data cleaning.
    """
    try:
        # Determine file extension
        file_ext = Path(file_path).suffix.lower()
        
        # Load file based on extension
        if file_ext == '.xlsx' or file_ext == '.xls':
            df = pd.read_excel(file_path)
            logger.info(f"Loaded {len(df)} rows from {file_path}")
        elif file_ext == '.csv':
            df = pd.read_csv(file_path)
            logger.info(f"Loaded {len(df)} rows from {file_path}")
        else:
            raise ValueError(f"Unsupported file format: {file_ext}")
        
        logger.info(f"Original columns: {list(df.columns)}")
        
        # STEP 1: Standardize column names
        logger.info("Standardizing column names...")
        df, applied_mappings = standardize_column_names(df)
        
        if applied_mappings:
            logger.info(f"Applied {len(applied_mappings)} column mappings")
        
        # STEP 2: Validate required columns exist
        logger.info("Validating required columns...")
        validate_required_columns(df)
        logger.info("All required columns present")
        
        # STEP 3: Add optional columns if missing
        if 'Description' not in df.columns:
            df['Description'] = 'Product'
        
        if 'InvoiceNo' not in df.columns:
            df['InvoiceNo'] = range(len(df))
        
        # STEP 4: Parse and clean data
        logger.info("Cleaning data...")
        
        # Parse date
        df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], errors='coerce')
        
        # Remove rows with invalid dates
        initial_rows = len(df)
        df = df.dropna(subset=['CustomerID', 'InvoiceDate', 'Quantity', 'UnitPrice'])
        rows_removed_invalid = initial_rows - len(df)
        if rows_removed_invalid > 0:
            logger.info(f"Removed {rows_removed_invalid} rows with invalid/missing data")
        
        # Remove rows with non-positive quantity or price
        initial_rows = len(df)
        df = df[(df['Quantity'] > 0) & (df['UnitPrice'] > 0)]
        rows_removed_invalid_values = initial_rows - len(df)
        if rows_removed_invalid_values > 0:
            logger.info(f"Removed {rows_removed_invalid_values} rows with non-positive Quantity or UnitPrice")
        
        # Ensure CustomerID is not null
        df = df[df['CustomerID'].notna()]
        
        # Calculate amount
        if 'Amount' not in df.columns:
            df['Amount'] = df['Quantity'] * df['UnitPrice']
            logger.info("Calculated 'Amount' column from Quantity × UnitPrice")
        
        logger.info(f"Final cleaned data: {len(df)} rows")
        
        return df
        
    except Exception as e:
        logger.error(f"Error loading data: {e}", exc_info=True)
        raise

def compute_rfm_with_log_transform(df, snapshot_date=None):
    """
    Compute RFM metrics with log transformation for Frequency and Monetary values.
    
    Recency: Days since last purchase
    Frequency: Number of purchases (log-transformed)
    Monetary: Total spending (log-transformed)
    """
    try:
        if snapshot_date is None:
            snapshot_date = df['InvoiceDate'].max() + timedelta(days=1)
        
        # Determine invoice column name
        invoice_col = 'InvoiceNo' if 'InvoiceNo' in df.columns else 'InvoiceID'
        
        # Group by customer
        rfm = df.groupby('CustomerID').agg({
            'InvoiceDate': lambda x: (snapshot_date - x.max()).days,
            invoice_col: 'count',
            'Amount': 'sum'
        }).reset_index()
        
        rfm.columns = ['CustomerID', 'Recency', 'Frequency', 'Monetary']
        
        # Apply log transformation to avoid skewness
        # Log(Frequency + 1) to handle customers with frequency=1
        rfm['Frequency_log'] = np.log1p(rfm['Frequency'])
        rfm['Monetary_log'] = np.log1p(rfm['Monetary'])
        
        logger.info(f"Computed RFM for {len(rfm)} customers")
        logger.info(f"Recency range: {rfm['Recency'].min()}-{rfm['Recency'].max()} days")
        logger.info(f"Frequency range: {rfm['Frequency'].min()}-{rfm['Frequency'].max()} purchases")
        logger.info(f"Monetary range: ${rfm['Monetary'].min():.2f}-${rfm['Monetary'].max():.2f}")
        
        return rfm
    except Exception as e:
        logger.error(f"Error computing RFM: {e}")
        raise

def scale_rfm_features(rfm):
    """Apply MinMax scaling to RFM features for K-means."""
    try:
        scaler = MinMaxScaler(feature_range=(0, 1))
        
        # Use log-transformed features for scaling
        rfm_features = rfm[['Recency', 'Frequency_log', 'Monetary_log']].values
        rfm_scaled = scaler.fit_transform(rfm_features)
        
        # Create scaled dataframe
        rfm_scaled_df = pd.DataFrame(
            rfm_scaled,
            columns=['Recency_scaled', 'Frequency_scaled', 'Monetary_scaled']
        )
        
        rfm = pd.concat([rfm, rfm_scaled_df], axis=1)
        
        logger.info("MinMax scaling applied: [0, 1]")
        return rfm, scaler
    except Exception as e:
        logger.error(f"Error scaling RFM: {e}")
        raise

# =============================================
# ELBOW METHOD ANALYSIS
# =============================================

def calculate_inertia_for_k_range(rfm, k_range=range(2, 11)):
    """
    Calculate KMeans inertia (WCSS) for a range of K values.
    
    Returns:
    - k_values: List of K values tested
    - inertias: List of inertia values for each K
    """
    k_values = list(k_range)
    inertias = []
    
    # Prepare scaled features
    rfm_features_scaled = rfm[['Recency_scaled', 'Frequency_scaled', 'Monetary_scaled']].values
    
    logger.info(f"Calculating inertia for K={k_values[0]} to K={k_values[-1]}...")
    
    for k in k_values:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        kmeans.fit(rfm_features_scaled)
        inertias.append(kmeans.inertia_)
        logger.info(f"  K={k}: Inertia={kmeans.inertia_:.4f}")
    
    logger.info(f"Inertia calculation complete")
    
    return k_values, inertias

def plot_elbow(k_values, inertias, output_path):
    """
    Create and save elbow plot.
    """
    try:
        # Create figure with larger size for better visibility
        plt.figure(figsize=(10, 6))
        
        # Plot inertia values
        plt.plot(k_values, inertias, 'bo-', linewidth=2, markersize=8)
        
        # Styling
        plt.xlabel('Number of Clusters (K)', fontsize=12, fontweight='bold')
        plt.ylabel('Within-Cluster Sum of Squares (WCSS)', fontsize=12, fontweight='bold')
        plt.title('Elbow Method for Optimal K', fontsize=14, fontweight='bold')
        plt.xticks(k_values)
        plt.grid(True, alpha=0.3)
        
        # Add value labels on points
        for k, inertia in zip(k_values, inertias):
            plt.annotate(f'{inertia:.2f}', 
                        xy=(k, inertia), 
                        xytext=(0, 10), 
                        textcoords='offset points',
                        ha='center',
                        fontsize=9)
        
        # Tight layout
        plt.tight_layout()
        
        # Save figure
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        logger.info(f"Elbow plot saved to {output_path}")
        
        # Close figure to free memory
        plt.close()
        
    except Exception as e:
        logger.error(f"Error creating plot: {e}")
        raise

# =============================================
# MAIN EXECUTION
# =============================================

def main():
    """Main execution function."""
    try:
        logger.info("=" * 60)
        logger.info("ELBOW METHOD ANALYSIS - RFM CLUSTERING")
        logger.info("=" * 60)
        
        # Find data file
        data_files = ['Online Retail.xlsx', 'Online Retail.csv', 'Sales_Data.csv', 'sample_data.csv']
        data_file = None
        
        for file in data_files:
            if os.path.exists(file):
                data_file = file
                break
        
        if not data_file:
            available_files = [f for f in os.listdir('.') if f.endswith(('.xlsx', '.csv', '.xls'))]
            logger.error(f"Could not find data file. Available files: {available_files}")
            raise FileNotFoundError(f"Could not find data file. Tried: {data_files}")
        
        logger.info(f"Using data file: {data_file}")
        
        # Load and clean data
        logger.info("\n--- STEP 1: Loading and Cleaning Data ---")
        df = load_and_clean_data(data_file)
        
        # Compute RFM with log transformation
        logger.info("\n--- STEP 2: Computing RFM with Log Transformation ---")
        rfm = compute_rfm_with_log_transform(df)
        
        # Scale RFM features
        logger.info("\n--- STEP 3: Scaling RFM Features ---")
        rfm, scaler = scale_rfm_features(rfm)
        
        # Calculate inertia for K=2 to 10
        logger.info("\n--- STEP 4: Elbow Method Analysis ---")
        k_values, inertias = calculate_inertia_for_k_range(rfm)
        
        # Create assets folder if it doesn't exist
        assets_dir = 'assets'
        os.makedirs(assets_dir, exist_ok=True)
        logger.info(f"Created/verified assets folder: {assets_dir}")
        
        # Plot and save
        logger.info("\n--- STEP 5: Generating Elbow Plot ---")
        output_path = os.path.join(assets_dir, 'elbow.png')
        plot_elbow(k_values, inertias, output_path)
        
        logger.info("\n" + "=" * 60)
        logger.info("✓ ELBOW ANALYSIS COMPLETE")
        logger.info("=" * 60)
        logger.info(f"Output: {output_path}")
        logger.info("\nInertia Summary:")
        for k, inertia in zip(k_values, inertias):
            logger.info(f"  K={k:2d}: {inertia:.4f}")
        
    except Exception as e:
        logger.error(f"\n✗ ANALYSIS FAILED: {e}", exc_info=True)
        raise

if __name__ == '__main__':
    main()
