"""
Redesigned Dashboard - 3 Main Tabs Architecture
Tab 1: Executive Overview (老板总览) - 1 minute daily check - GLOBAL FILTERS VISIBLE
Tab 2: Customer Segmentation (客户深度分析) - FYP Core with 3D RFM + Datatable - LOCAL SEGMENT FILTER
Tab 3: Advanced Insights (进阶洞察) - Pareto, Market Basket, Geographic - GLOBAL FILTERS VISIBLE
"""

from dash import html, dcc, Input, Output, callback, State, no_update
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
from data_processing import (
    calculate_churn_rate, get_active_customers_count,
    prepare_cluster_profile_data,
    prepare_sales_heatmap_data, prepare_monthly_sales_trend,
    prepare_top_products,
    prepare_pareto_analysis
)
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# =============================================
# HELPER FUNCTIONS
# =============================================

def get_date_range_from_period(selected_period, data_start_date, data_end_date):
    """Convert period dropdown value to actual start and end dates."""
    try:
        data_end = pd.to_datetime(data_end_date)
        data_start = pd.to_datetime(data_start_date)
        
        period_map = {
            'last_7': data_end - timedelta(days=7),
            'last_14': data_end - timedelta(days=14),
            'last_30': data_end - timedelta(days=30),
            'last_90': data_end - timedelta(days=90),
            'last_180': data_end - timedelta(days=180),
            'all_time': data_start,
        }
        
        selected_start = period_map.get(selected_period, data_start)
        
        # Ensure dates are within data range
        if selected_start < data_start:
            selected_start = data_start
        
        return selected_start.date(), data_end.date()
    except Exception as e:
        logger.error(f"[HELPER] Error converting period: {e}")
        return data_start_date, data_end_date

# =============================================
# DASHBOARD RENDERING - 3 TABS MAIN STRUCTURE
# =============================================

def render_new_dashboard():
    """Render the complete 3-tab dashboard with global filter."""
    return html.Div([
        # Header with Logout Button
        html.Div([
            html.Div([
                html.H1('📊 E-Commerce Analytics Platform', 
                       style={'color': '#fff', 'marginBottom': '5px', 'fontSize': '32px'}),
                html.P('Executive Overview | Customer Segmentation | Advanced Insights',
                      style={'color': '#e0e0e0', 'marginTop': '0', 'fontSize': '14px'})
            ], style={'flex': '1'}),
            html.Button(
                '🚪 Logout',
                id='logout-button',
                n_clicks=0,
                style={
                    'backgroundColor': '#ff6b6b',
                    'color': 'white',
                    'border': 'none',
                    'padding': '10px 20px',
                    'borderRadius': '4px',
                    'fontSize': '14px',
                    'fontWeight': 'bold',
                    'cursor': 'pointer',
                    'transition': 'background-color 0.3s'
                }
            )
        ], style={
            'backgroundColor': '#667eea',
            'padding': '20px 30px',
            'marginBottom': '0',
            'borderRadius': '0',
            'boxShadow': '0 2px 8px rgba(0,0,0,0.1)',
            'display': 'flex',
            'justifyContent': 'space-between',
            'alignItems': 'center'
        }),
        
        # Global Filter Panel - Year/Month Selector (Hidden on Tab 2: Customer Segmentation)
        html.Div([
            html.Div([
                html.Div([
                    html.Label('Select Period:', style={'fontWeight': 'bold', 'marginBottom': '8px', 'display': 'block', 'fontSize': '13px'}),
                    dcc.Dropdown(
                        id='global-date-filter',
                        options=[
                            {'label': '📅 Last 7 Days', 'value': 'last_7'},
                            {'label': '📅 Last 14 Days', 'value': 'last_14'},
                            {'label': '📅 Last 30 Days', 'value': 'last_30'},
                            {'label': '📅 Last 90 Days', 'value': 'last_90'},
                            {'label': '📅 Last 6 Months', 'value': 'last_180'},
                            {'label': '📅 All Time', 'value': 'all_time'},
                        ],
                        value='last_30',
                        style={'width': '100%', 'padding': '8px', 'borderRadius': '4px', 'border': '1px solid #ddd', 'color': '#333', 'backgroundColor': 'white'}
                    ),
                    dcc.Store(id='global-date-filter-store', data={'start_date': None, 'end_date': None}),
                    dcc.Store(id='calculated-dates-store', data={'start_date': None, 'end_date': None})
                ], style={'flex': '1', 'minWidth': '300px'}),
                
                html.Div([
                    html.Label('Customer Segment (Global):', style={'fontWeight': 'bold', 'marginBottom': '8px', 'display': 'block', 'fontSize': '13px'}),
                    dcc.Dropdown(
                        id='global-segment-filter',
                        options=[
                            {'label': '📊 All Segments', 'value': 'All'},
                            {'label': '⭐ High Value', 'value': 'High Value'},
                            {'label': '💼 Mid Value', 'value': 'Mid Value'},
                            {'label': '📍 Low Value', 'value': 'Low Value'},
                            {'label': '⚠️ At Risk', 'value': 'At Risk'},
                        ],
                        value='All',
                        style={'width': '100%', 'padding': '8px', 'borderRadius': '4px', 'border': '1px solid #ddd'}
                    )
                ], style={'flex': '1', 'minWidth': '200px', 'marginLeft': '15px'})
            ], style={'display': 'flex', 'gap': '15px', 'alignItems': 'flex-end', 'id': 'filter-row'}),
            
            html.Div(id='filter-info', style={
                'marginTop': '15px',
                'padding': '10px',
                'backgroundColor': '#f0f0f0',
                'borderRadius': '4px',
                'fontSize': '12px',
                'color': '#666'
            }, children='Filter: All data, All segments')
        ], style={
            'padding': '20px 30px',
            'backgroundColor': '#f9f9f9',
            'borderBottom': '1px solid #ddd',
            'marginBottom': '20px',
            'display': 'block'
        }, id='filter-panel-container'),
        
        # Hidden store for active tab
        dcc.Store(id='active-tab-store', data={'active_tab': 'tab-1'}),
        
        # Main Tab Interface
        dcc.Tabs(id='main-tabs', value='tab-1', style={
            'borderBottom': '3px solid #667eea',
            'marginBottom': '0',
            'backgroundColor': '#fff',
            'fontWeight': 'bold',
            'paddingLeft': '30px',
            'marginTop': '0'
        }, content_style={
            'padding': '20px 30px',
            'backgroundColor': '#f5f5f5',
            'minHeight': '80vh'
        }, children=[
            # TAB 1: EXECUTIVE OVERVIEW (1 minute daily check)
            dcc.Tab(label='📊 Executive Overview', value='tab-1', style={
                'padding': '12px 20px',
                'fontWeight': 'bold'
            }, selected_style={
                'padding': '12px 20px',
                'fontWeight': 'bold',
                'borderBottom': '3px solid #667eea'
            }, children=[
                # Top: 4 KPI Cards
                html.Div([
                    html.H3('Key Performance Indicators', style={'marginTop': '0', 'marginBottom': '15px'}),
                    html.Div(id='kpi-scorecard', style={
                        'display': 'grid',
                        'gridTemplateColumns': 'repeat(auto-fit, minmax(220px, 1fr))',
                        'gap': '15px',
                        'marginBottom': '30px'
                    })
                ], style={'marginBottom': '30px'}),
                
                # Middle: Monthly Trend + Sales Heatmap
                html.Div([
                    html.Div([
                        html.H3('Monthly Sales Trend', style={'marginTop': '0', 'fontSize': '16px'}),
                        dcc.Graph(id='exec-monthly-trend', style={'height': '350px'})
                    ], style={
                        'flex': '1',
                        'backgroundColor': '#fff',
                        'padding': '20px',
                        'borderRadius': '8px',
                        'boxShadow': '0 2px 4px rgba(0,0,0,0.1)',
                        'minWidth': '0'
                    }),
                    
                    html.Div([
                        html.H3('Sales Heatmap (Day vs Hour)', style={'marginTop': '0', 'fontSize': '16px'}),
                        dcc.Graph(id='exec-sales-heatmap', style={'height': '350px'})
                    ], style={
                        'flex': '1',
                        'backgroundColor': '#fff',
                        'padding': '20px',
                        'borderRadius': '8px',
                        'boxShadow': '0 2px 4px rgba(0,0,0,0.1)',
                        'minWidth': '0'
                    })
                ], style={'display': 'flex', 'gap': '15px', 'marginBottom': '20px'}),
                
                # Bottom: Top 5 Products
                html.Div([
                    html.H3('Top 5 Best Sellers', style={'marginTop': '0', 'marginBottom': '15px'}),
                    dcc.Graph(id='exec-top-5-products', style={'height': '300px'})
                ], style={
                    'backgroundColor': '#fff',
                    'padding': '20px',
                    'borderRadius': '8px',
                    'boxShadow': '0 2px 4px rgba(0,0,0,0.1)'
                })
            ]),
            
            # TAB 2: CUSTOMER SEGMENTATION (FYP Core) - LOCAL SEGMENT FILTER
            dcc.Tab(label='👥 Customer Segmentation', value='tab-2', style={
                'padding': '12px 20px',
                'fontWeight': 'bold'
            }, selected_style={
                'padding': '12px 20px',
                'fontWeight': 'bold',
                'borderBottom': '3px solid #667eea'
            }, children=[
                # Top: 3D RFM + Top 5 Countries
                html.Div([
                    html.Div([
                        html.H3('3D RFM Customer Space (Clustering Visualization)', 
                               style={'marginTop': '0', 'fontSize': '16px'}),
                        html.P('Your ML Algorithm Result: Clear cluster boundaries showing distinct customer groups',
                              style={'fontSize': '12px', 'color': '#999'}),
                        dcc.Graph(id='segment-3d-rfm', style={'height': '450px'})
                    ], style={
                        'flex': '1',
                        'backgroundColor': '#fff',
                        'padding': '20px',
                        'borderRadius': '8px',
                        'boxShadow': '0 2px 4px rgba(0,0,0,0.1)',
                        'minWidth': '0'
                    }),
                    
                    html.Div([
                        html.H3('Top 5 Countries by Revenue', 
                               style={'marginTop': '0', 'fontSize': '16px'}),
                        html.P('Historical sales distribution across top countries',
                              style={'fontSize': '12px', 'color': '#999'}),
                        dcc.Graph(id='local-segment-top-countries', style={'height': '450px'})
                    ], style={
                        'flex': '1',
                        'backgroundColor': '#fff',
                        'padding': '20px',
                        'borderRadius': '8px',
                        'boxShadow': '0 2px 4px rgba(0,0,0,0.1)',
                        'minWidth': '0'
                    })
                ], style={'display': 'flex', 'gap': '15px', 'marginBottom': '20px'}),
                
                # Second Row: Group Profile Comparison
                html.Div([
                    html.Div([
                        html.H3('Group Profile Comparison (R, F, M)', 
                               style={'marginTop': '0', 'fontSize': '16px'}),
                        html.P('Average values for each customer segment',
                              style={'fontSize': '12px', 'color': '#999'}),
                        dcc.Graph(id='segment-group-profile', style={'height': '350px'})
                    ], style={
                        'flex': '1',
                        'backgroundColor': '#fff',
                        'padding': '20px',
                        'borderRadius': '8px',
                        'boxShadow': '0 2px 4px rgba(0,0,0,0.1)',
                        'minWidth': '0'
                    })
                ], style={'display': 'flex', 'gap': '15px', 'marginBottom': '20px'}),
                
                # Local Toolbar: 3-Column Layout (Title + Filter | Spacer | Buttons)
                html.Div([
                    # Column 1: Title + Filter Controls (Left)
                    html.Div([
                        html.Div([
                            html.H3('Customer List (Downloadable)', 
                                   style={'marginTop': '0', 'marginBottom': '0', 'fontSize': '18px', 'fontWeight': 'bold', 'marginRight': '30px'})
                        ], style={
                            'display': 'flex',
                            'alignItems': 'center'
                        }),
                        html.Div([
                            html.Label('Filter by Segment:', style={
                                'fontWeight': 'bold',
                                'marginBottom': '0',
                                'marginRight': '10px',
                                'fontSize': '13px',
                                'whiteSpace': 'nowrap',
                                'display': 'inline-block'
                            }),
                            dcc.Dropdown(
                                id='local-segment-filter',
                                options=[
                                    {'label': '📊 All Segments', 'value': 'All'},
                                    {'label': '⭐ High Value', 'value': 'High Value'},
                                    {'label': '💼 Mid Value', 'value': 'Mid Value'},
                                    {'label': '📍 Low Value', 'value': 'Low Value'},
                                    {'label': '⚠️ At Risk', 'value': 'At Risk'},
                                ],
                                value='All',
                                style={
                                    'width': '160px',
                                    'padding': '8px',
                                    'borderRadius': '4px',
                                    'border': '1px solid #ddd',
                                    'display': 'inline-block',
                                    'verticalAlign': 'middle',
                                    'flexShrink': '0'
                                }
                            ),
                        ], style={'display': 'flex', 'alignItems': 'center', 'gap': '5px', 'minWidth': '0', 'flexWrap': 'nowrap'})
                    ], style={
                        'flex': '0 0 auto',
                        'display': 'flex',
                        'alignItems': 'center',
                        'gap': '20px'
                    }),
                    
                    # Spacer
                    html.Div(style={'flex': '1'}),
                    
                    # Column 3: Buttons (Right)
                    html.Div([
                        html.Button(
                            '⬇️ Download CSV',
                            id='local-download-customer-list-btn',
                            n_clicks=0,
                            style={
                                'backgroundColor': '#51cf66',
                                'color': 'white',
                                'border': 'none',
                                'padding': '8px 15px',
                                'borderRadius': '4px',
                                'cursor': 'pointer',
                                'fontSize': '13px',
                                'fontWeight': 'bold',
                                'marginLeft': '10px',
                                'transition': 'background-color 0.3s'
                            }
                        ),
                        html.Button(
                            '🔍 Expand',
                            id='local-expand-customer-list-btn',
                            n_clicks=0,
                            style={
                                'backgroundColor': '#4dabf7',
                                'color': 'white',
                                'border': 'none',
                                'padding': '8px 15px',
                                'borderRadius': '4px',
                                'cursor': 'pointer',
                                'fontSize': '13px',
                                'fontWeight': 'bold',
                                'marginLeft': '10px',
                                'transition': 'background-color 0.3s'
                            }
                        ),
                        dcc.Download(id='local-download-customer-list')
                    ], style={
                        'flex': '0 0 auto',
                        'display': 'flex',
                        'alignItems': 'center',
                        'justifyContent': 'flex-end',
                        'gap': '0'
                    })
                ], style={
                    'display': 'flex',
                    'justifyContent': 'space-between',
                    'alignItems': 'center',
                    'padding': '20px',
                    'backgroundColor': '#fff',
                    'borderRadius': '8px',
                    'boxShadow': '0 2px 4px rgba(0,0,0,0.1)',
                    'marginBottom': '20px'
                }),
                
                # Bottom: Customer List (Datatable)
                html.Div([
                    html.Div(id='local-segment-customer-table', style={
                        'backgroundColor': '#fff',
                        'padding': '20px',
                        'borderRadius': '8px',
                        'boxShadow': '0 2px 4px rgba(0,0,0,0.1)',
                        'overflowX': 'auto'
                    })
                ], style={'marginBottom': '0'}),
                
                # MODAL for Expanded View
                dbc.Modal([
                    dbc.ModalHeader('Customer List (Expanded View)', close_button=True),
                    dbc.ModalBody([
                        html.Div(id='modal-customer-table', style={'overflowX': 'auto'})
                    ], style={'maxHeight': '80vh', 'overflowY': 'auto'}),
                    dbc.ModalFooter([
                        dbc.Button('Close', id='close-modal-btn', className='ms-auto', n_clicks=0)
                    ])
                ], id='customer-list-modal', size='xl', is_open=False, scrollable=True)
            ]),
            
            # TAB 3: ADVANCED INSIGHTS (Monthly strategy)
            dcc.Tab(label='📈 Advanced Insights', value='tab-3', style={
                'padding': '12px 20px',
                'fontWeight': 'bold'
            }, selected_style={
                'padding': '12px 20px',
                'fontWeight': 'bold',
                'borderBottom': '3px solid #667eea'
            }, children=[
                html.Div([
                    dcc.Tabs(
                        id='advanced-tabs',
                        value='advanced-tab-0',
                        style={'borderBottom': '1px solid #ddd', 'marginBottom': '20px', 'maxWidth': '1200px', 'margin': '0 auto 20px auto'},
                        content_style={'padding': '0'},
                        children=[
                            dcc.Tab(label='🎯 Product Portfolio (Pareto)', value='advanced-tab-0', children=[
                                html.Div([
                                    html.H3('📊 Product Portfolio Analysis - Pareto Principle', 
                                           style={'textAlign': 'center', 'marginBottom': '10px', 'color': '#333'}),
                                    html.P('Identify the "Vital Few" products that drive 80% of your revenue. Red line shows cumulative contribution %.',
                                          style={'textAlign': 'center', 'fontSize': '13px', 'color': '#999', 'marginBottom': '20px'}),
                                    dcc.Graph(id='pareto-chart', style={'height': '600px'}),
                                    html.Div([
                                        html.H4('🔝 Core Products (Top 20% Contribution)', style={'marginTop': '30px', 'marginBottom': '15px', 'color': '#333'}),
                                        html.Div(id='core-products-table', style={'overflowX': 'auto'})
                                    ], style={'maxWidth': '1200px', 'margin': '0 auto', 'padding': '0 20px'})
                                ], style={'maxWidth': '1200px', 'margin': '0 auto', 'width': '100%', 'padding': '20px'})
                            ]),
                            dcc.Tab(label='📈 K-Means Detailed', value='advanced-tab-1', children=[
                                html.Div([
                                    html.P('Optimal K Selection (Elbow Method): The plot below confirms K=4 is the optimal cluster count.', 
                                           style={'textAlign': 'center', 'color': '#666', 'fontSize': '14px', 'maxWidth': '800px', 'margin': '20px auto', 'fontWeight': '500'}),
                                    html.Img(src='/assets/elbow.png', style={'width': '100%', 'maxWidth': '800px', 'display': 'block', 'margin': '20px auto', 'borderRadius': '8px', 'boxShadow': '0 2px 8px rgba(0,0,0,0.1)'})
                                ], style={'maxWidth': '1200px', 'margin': '0 auto', 'width': '100%', 'padding': '20px'})
                            ])
                        ]
                    )
                ], style={'padding': '20px'})
            ])
        ]),
        
        # STATUS ALERT (REQUIREMENT 2: Success/Error Messages)
        html.Div(id='status-alert', style={
            'position': 'fixed',
            'top': '100px',
            'right': '20px',
            'zIndex': '9999',
            'maxWidth': '400px'
        }),
        
        # LOADING SPINNER WRAPPER (REQUIREMENT 1: Global Loading State)
        dcc.Loading(
            id='loading-spinner',
            type='default',
            fullscreen=True,
            children=[
                html.Div(id='tab-content-wrapper', children=[
                    # Tab content goes here via callback
                ])
            ]
        ),
        
        # Hidden stores
        dcc.Store(id='rfm-data-store'),
        dcc.Store(id='transaction-data-store'),
    ], style={'padding': '0', 'backgroundColor': '#f5f5f5', 'minHeight': '100vh'})

# =============================================
# KPI SCORECARD CARD COMPONENT
# =============================================

def create_kpi_card(title, value, unit='', icon='📊', color='#667eea', subtitle=''):
    """Create a single KPI card with title, value, and optional subtitle."""
    return html.Div([
        html.Div([
            html.Span(icon, style={'fontSize': '40px', 'marginRight': '15px'}),
            html.Div([
                html.P(title, style={'margin': '0', 'fontSize': '12px', 'color': '#999', 'fontWeight': '600'}),
                html.P(f'{value}{unit}', style={'margin': '5px 0 0 0', 'fontSize': '24px', 'fontWeight': 'bold', 'color': color}),
                html.P(subtitle, style={'margin': '5px 0 0 0', 'fontSize': '11px', 'color': '#ccc'}) if subtitle else html.Div()
            ], style={'flex': '1'})
        ], style={'display': 'flex', 'alignItems': 'center'})
    ], style={
        'padding': '20px',
        'backgroundColor': '#fff',
        'borderRadius': '8px',
        'boxShadow': '0 2px 4px rgba(0,0,0,0.1)',
        'borderLeft': f'5px solid {color}',
        'minHeight': '100px'
    })

# =============================================
# CALLBACKS FOR 3-TAB ARCHITECTURE
# =============================================

def register_new_dashboard_callbacks(app, load_data, preprocess, compute_rfm_with_log_transform,
                                    scale_rfm_features, perform_kmeans_clustering):
    """Register all dashboard callbacks for 3-tab architecture."""
    
    @app.callback(
        Output('login-store', 'data'),
        Input('logout-button', 'n_clicks'),
        prevent_initial_call=True
    )
    def handle_logout(n_clicks):
        """Handle logout - clear login state."""
        if n_clicks and n_clicks > 0:
            logger.info("[DASHBOARD] Logout clicked - clearing session")
            return {'logged_in': False, 'username': '', 'show_register': False}
        return no_update
    
    @app.callback(
        [Output('filter-panel-container', 'style'),
         Output('main-tabs', 'style'),
         Output('active-tab-store', 'data')],
        Input('main-tabs', 'value'),
        prevent_initial_call=False
    )
    def toggle_filter_visibility(active_tab):
        """Toggle filter visibility and adjust spacing based on active tab. Hide filters on Segmentation tab."""
        # Update active tab store
        active_tab_data = {'active_tab': active_tab}
        
        # Determine filter visibility
        if active_tab == 'tab-2':  # Customer Segmentation tab - HIDE filters
            filter_style = {
                'padding': '20px 30px',
                'backgroundColor': '#f9f9f9',
                'borderBottom': '1px solid #ddd',
                'marginBottom': '20px',
                'display': 'none'
            }
            # Preserve space for hidden filter panel to prevent jumping
            tabs_style = {
                'borderBottom': '3px solid #667eea',
                'marginBottom': '0',
                'backgroundColor': '#fff',
                'fontWeight': 'bold',
                'paddingLeft': '30px',
                'marginTop': '20px'  # Preserve vertical spacing
            }
        elif active_tab == 'tab-1':  # Executive Overview - SHOW filters
            filter_style = {
                'padding': '20px 30px',
                'backgroundColor': '#f9f9f9',
                'borderBottom': '1px solid #ddd',
                'marginBottom': '20px',
                'display': 'block'
            }
            tabs_style = {
                'borderBottom': '3px solid #667eea',
                'marginBottom': '0',
                'backgroundColor': '#fff',
                'fontWeight': 'bold',
                'paddingLeft': '30px',
                'marginTop': '0'
            }
        else:  # Advanced Insights (tab-3) - SHOW filters
            filter_style = {
                'padding': '20px 30px',
                'backgroundColor': '#f9f9f9',
                'borderBottom': '1px solid #ddd',
                'marginBottom': '20px',
                'display': 'block'
            }
            tabs_style = {
                'borderBottom': '3px solid #667eea',
                'marginBottom': '0',
                'backgroundColor': '#fff',
                'fontWeight': 'bold',
                'paddingLeft': '30px',
                'marginTop': '0'
            }
        
        logger.info(f"[FILTER] Tab changed to '{active_tab}' - filter visibility: {'hidden' if active_tab == 'tab-2' else 'visible'}")
        return filter_style, tabs_style, active_tab_data
    
    
    @app.callback(
        [Output('rfm-data-store', 'data'),
         Output('transaction-data-store', 'data'),
         Output('global-date-filter-store', 'data'),
         Output('global-date-filter', 'value')],
        Input('data-store', 'data'),
        prevent_initial_call=False
    )
    def store_processed_data(store_data):
        """Store RFM and transaction data when available. Set default date filter to last 30 days of data."""
        try:
            # Try to get data from global cache first (memory storage)
            from upload import _uploaded_data_cache
            
            if _uploaded_data_cache and _uploaded_data_cache.get('tx_json'):
                logger.info("[DASHBOARD] 📦 Using cached data from memory")
                tx_json = _uploaded_data_cache.get('tx_json')
                rfm_json = _uploaded_data_cache.get('rfm_json')
                
                if tx_json and rfm_json:
                    # Parse to get date range
                    tx_data = pd.read_json(tx_json)
                    tx_data['InvoiceDate'] = pd.to_datetime(tx_data['InvoiceDate'], errors='coerce')
                    start_date = tx_data['InvoiceDate'].min().date()
                    end_date = tx_data['InvoiceDate'].max().date()
                    
                    logger.info(f"[DASHBOARD] Data loaded from cache. Date range: {start_date} to {end_date}")
                    return rfm_json, tx_json, {'start_date': str(start_date), 'end_date': str(end_date)}, 'last_30'
            
            # Fallback to store_data if cache is empty
            if not store_data or not store_data.get('tx_json'):
                logger.info("[DASHBOARD] No data available yet")
                return None, None, {'start_date': None, 'end_date': None}, 'last_30'
            
            tx_json = store_data.get('tx_json')
            rfm_json = store_data.get('rfm_json')
            
            if tx_json and rfm_json:
                # Parse to get date range
                tx_data = pd.read_json(tx_json)
                tx_data['InvoiceDate'] = pd.to_datetime(tx_data['InvoiceDate'], errors='coerce')
                start_date = tx_data['InvoiceDate'].min().date()
                end_date = tx_data['InvoiceDate'].max().date()
                
                logger.info(f"[DASHBOARD] Data loaded from store. Date range: {start_date} to {end_date}")
                return rfm_json, tx_json, {'start_date': str(start_date), 'end_date': str(end_date)}, 'last_30'
            
            return None, None, {'start_date': None, 'end_date': None}, 'last_30'
        except Exception as e:
            logger.error(f"[DASHBOARD] Error storing data: {e}", exc_info=True)
            return None, None, {'start_date': None, 'end_date': None}, 'last_30'

    
    @app.callback(
        Output('calculated-dates-store', 'data'),
        [Input('global-date-filter', 'value'),
         Input('global-date-filter-store', 'data')],
        prevent_initial_call=False
    )
    def calculate_date_range(selected_period, date_store):
        """Calculate actual start and end dates based on dropdown selection."""
        try:
            if not date_store or not date_store.get('start_date') or not date_store.get('end_date'):
                return {'start_date': None, 'end_date': None}
            
            start_date, end_date = get_date_range_from_period(selected_period, date_store.get('start_date'), date_store.get('end_date'))
            logger.info(f"[FILTER] Calculated dates for '{selected_period}': {start_date} to {end_date}")
            
            return {'start_date': str(start_date), 'end_date': str(end_date)}
        except Exception as e:
            logger.error(f"[FILTER] Error calculating dates: {e}")
            return {'start_date': None, 'end_date': None}
    
    @app.callback(
        [Output('kpi-scorecard', 'children', allow_duplicate=True)],
        [Input('global-date-filter', 'value'),
         Input('global-date-filter-store', 'data'),
         Input('transaction-data-store', 'data')],
        prevent_initial_call=True
    )
    def trigger_updates_on_filter_change(selected_period, date_store, tx_data):
        """Trigger other callbacks when filter changes."""
        return [no_update]
    
    @app.callback(
        Output('filter-info', 'children'),
        [Input('global-date-filter', 'value'),
         Input('calculated-dates-store', 'data'),
         Input('global-segment-filter', 'value')],
        prevent_initial_call=False
    )
    def update_filter_info(selected_period, calculated_dates, segment):
        """Update filter info display."""
        try:
            if not calculated_dates or not calculated_dates.get('start_date') or not calculated_dates.get('end_date'):
                return 'Filter: Loading data...'
            
            start_str = calculated_dates.get('start_date')
            end_str = calculated_dates.get('end_date')
            
            segment_str = segment if segment != 'All' else 'All segments'
            period_label = selected_period.replace('_', ' ').title()
            
            return f'Filter: {start_str} to {end_str} ({period_label}) | {segment_str}'
        except Exception as e:
            logger.error(f"[FILTER] Error updating info: {e}")
            return 'Filter: All data'

    # ===== REQUIREMENT 2: GLOBAL STATUS ALERTS CALLBACK =====
    
    @app.callback(
        Output('status-alert', 'children'),
        [Input('main-tabs', 'value'),
         Input('global-date-filter', 'value'),
         Input('global-segment-filter', 'value'),
         Input('local-segment-filter', 'value'),
         Input('rfm-data-store', 'data'),
         Input('transaction-data-store', 'data'),
         Input('calculated-dates-store', 'data')],
        prevent_initial_call=False
    )
    def update_global_status_alerts(active_tab, global_date, global_segment, local_segment, 
                                   rfm_data, tx_data, calculated_dates):
        """
        REQUIREMENT 2: Global status alerts for ALL tabs.
        
        - Tab 1 & 3 (Executive & Advanced): Check global filters (date + segment)
        - Tab 2 (Segmentation): Check local segment filter
        
        Returns dbc.Alert with success/error messages based on data availability.
        """
        try:
            # If no data uploaded yet, don't show alerts
            if not rfm_data or not tx_data:
                return None
            
            # TAB 1 & 3: Executive Overview and Advanced Insights (use GLOBAL filters)
            if active_tab in ['tab-1', 'tab-3']:
                tx_df = pd.read_json(tx_data)
                tx_df['InvoiceDate'] = pd.to_datetime(tx_df['InvoiceDate'], errors='coerce')
                
                # Apply date filter
                if calculated_dates and calculated_dates.get('start_date') and calculated_dates.get('end_date'):
                    start = pd.to_datetime(calculated_dates.get('start_date'))
                    end = pd.to_datetime(calculated_dates.get('end_date'))
                    tx_df = tx_df[(tx_df['InvoiceDate'] >= start) & (tx_df['InvoiceDate'] <= end)]
                
                # Apply global segment filter
                if global_segment and global_segment != 'All' and rfm_data:
                    try:
                        rfm_df = pd.read_json(rfm_data)
                        # KEY FIX: Convert CustomerID to string to match transaction data
                        rfm_df['CustomerID'] = rfm_df['CustomerID'].astype(str).str.split('.').str[0]
                        tx_df['CustomerID'] = tx_df['CustomerID'].astype(str).str.split('.').str[0]
                        segment_customers = rfm_df[rfm_df['Segment'] == global_segment]['CustomerID'].tolist()
                        tx_df = tx_df[tx_df['CustomerID'].isin(segment_customers)]
                    except Exception as e:
                        logger.warning(f"[ALERTS] Could not apply global segment filter: {e}")
                
                # Check if filtered data is empty
                if len(tx_df) == 0:
                    return dbc.Alert(
                        "❌ No data available for this global selection.",
                        color="danger",
                        dismissable=True,
                        is_open=True,
                        style={'marginBottom': '0'}
                    )
                else:
                    return dbc.Alert(
                        "✅ Data loaded successfully.",
                        color="success",
                        dismissable=True,
                        is_open=True,
                        duration=3000,
                        style={'marginBottom': '0'}
                    )
            
            # TAB 2: Customer Segmentation (use LOCAL filter)
            elif active_tab == 'tab-2':
                if not rfm_data:
                    return None
                
                rfm_df = pd.read_json(rfm_data)
                
                # Apply local segment filter
                if local_segment and local_segment != 'All':
                    rfm_df = rfm_df[rfm_df['Segment'] == local_segment]
                
                # Check if filtered data is empty
                if len(rfm_df) == 0:
                    return dbc.Alert(
                        f"❌ No customers found in {local_segment} segment.",
                        color="danger",
                        dismissable=True,
                        is_open=True,
                        style={'marginBottom': '0'}
                    )
                else:
                    return dbc.Alert(
                        "✅ Segment data loaded successfully.",
                        color="success",
                        dismissable=True,
                        is_open=True,
                        duration=3000,
                        style={'marginBottom': '0'}
                    )
            
            return None
        except Exception as e:
            logger.error(f"[ALERTS] Error in status alert callback: {e}")
            return None
    
    # ===== TAB 1: EXECUTIVE OVERVIEW CALLBACKS (FIXED) =====
    
    @app.callback(
        Output('kpi-scorecard', 'children'),
        [Input('rfm-data-store', 'data'),
         Input('transaction-data-store', 'data'),
         Input('calculated-dates-store', 'data'),
         Input('global-segment-filter', 'value')],
        prevent_initial_call=False
    )
    def update_kpi_scorecard(rfm_data, tx_data, calculated_dates, selected_segment):
        """Update KPI scorecard with ROBUST ID matching and filtering."""
        try:
            if not rfm_data or not tx_data:
                # Return zeros if no data
                return [create_kpi_card(t, '0', icon=i, color=c) for t, i, c in 
                        [('Total Revenue', '💰', '#51cf66'), ('Avg Order Value', '🛒', '#4dabf7'), 
                         ('Active Customers', '👥', '#ffd43b'), ('Churn Rate', '⚠️', '#ff6b6b')]]
            
            rfm_df = pd.read_json(rfm_data)
            tx_df = pd.read_json(tx_data)
            
            # FIX 1: Force IDs to String (handle 12345.0 vs "12345")
            if 'CustomerID' in tx_df.columns:
                tx_df['CustomerID'] = tx_df['CustomerID'].astype(str).str.split('.').str[0]
            rfm_df['CustomerID'] = rfm_df['CustomerID'].astype(str).str.split('.').str[0]
            
            # Apply DATE Filter
            tx_df['InvoiceDate'] = pd.to_datetime(tx_df['InvoiceDate'], errors='coerce')
            if calculated_dates and calculated_dates.get('start_date') and calculated_dates.get('end_date'):
                start = pd.to_datetime(calculated_dates.get('start_date'))
                end = pd.to_datetime(calculated_dates.get('end_date'))
                tx_df = tx_df[(tx_df['InvoiceDate'] >= start) & (tx_df['InvoiceDate'] <= end)]
            
            # Apply SEGMENT Filter (Filter Transactions by matching IDs from RFM segment)
            if selected_segment != 'All':
                # Get IDs belonging to this segment
                segment_ids = rfm_df[rfm_df['Segment'] == selected_segment]['CustomerID'].tolist()
                # Filter sales to only these customers
                tx_df = tx_df[tx_df['CustomerID'].isin(segment_ids)]
                
                # Filter RFM df for churn/active calcs
                rfm_analysis_df = rfm_df[rfm_df['Segment'] == selected_segment]
            else:
                rfm_analysis_df = rfm_df

            # Compute KPIs
            total_revenue = tx_df['Amount'].sum()
            num_orders = len(tx_df)
            aov = total_revenue / num_orders if num_orders > 0 else 0
            
            # Calculate Active/Churn based on the filtered RFM list
            active_count = get_active_customers_count(rfm_analysis_df, days_threshold=30)
            churn_rate, _, _ = calculate_churn_rate(rfm_analysis_df, days_threshold=30)
            
            return [
                create_kpi_card('Total Revenue (GBP)', f'£{total_revenue:,.0f}', icon='💰', color='#51cf66', subtitle=f'{num_orders} orders'),
                create_kpi_card('Average Order Value (GBP)', f'£{aov:,.0f}', icon='🛒', color='#4dabf7', subtitle='Per transaction'),
                create_kpi_card('Active Customers', f'{active_count:,}', icon='👥', color='#ffd43b', subtitle='Within 30 days'),
                create_kpi_card('Churn Rate (%)', f'{churn_rate:.1f}%', icon='⚠️', color='#ff6b6b', subtitle='Inactive 30+ days'),
            ]
        except Exception as e:
            logger.error(f"[KPI] Error: {e}", exc_info=True)
            return []
    
    @app.callback(
        Output('exec-monthly-trend', 'figure'),
        [Input('transaction-data-store', 'data'),
         Input('calculated-dates-store', 'data'),
         Input('global-segment-filter', 'value'),
         Input('rfm-data-store', 'data'),
         Input('global-date-filter', 'value')],
        prevent_initial_call=False
    )
    def update_exec_monthly_trend(tx_data, calculated_dates, selected_segment, rfm_data, selected_period):
        """Update Sales Trend with Proper Alignment and Labeling.
        
        ALIGNMENT FIX: Changed resample('M') to resample('MS') to align data points 
        to month START instead of month END, ensuring perfect alignment with X-axis labels.
        
        LABELING FIX: Added tickmode='linear' to force Plotly to show a label for 
        every single tick (preventing it from skipping months or days).
        
        DAILY MODE (Last 7-30 Days):
        - Data shown for every single day
        - X-Axis labels: "01 Jan 2011" (Day, Month, Year)
        - Tick marks forced for every day (dtick='D1')
        
        MONTHLY MODE (Last 90 Days - All Time):
        - Data aggregated by month (Month Start)
        - X-Axis labels: "Jan 2011" (Month, Year)
        - Tick marks forced for every month (dtick='M1')
        """
        try:
            if not tx_data:
                return go.Figure().add_annotation(text='No data available', showarrow=False)
            
            tx_df = pd.read_json(tx_data)
            tx_df['InvoiceDate'] = pd.to_datetime(tx_df['InvoiceDate'], errors='coerce')
            
            # FIX 1: Robust ID & Segment Filter
            if selected_segment != 'All' and rfm_data:
                rfm_df = pd.read_json(rfm_data)
                rfm_df['CustomerID'] = rfm_df['CustomerID'].astype(str).str.split('.').str[0]
                if 'CustomerID' in tx_df.columns:
                    tx_df['CustomerID'] = tx_df['CustomerID'].astype(str).str.split('.').str[0]
                    segment_ids = rfm_df[rfm_df['Segment'] == selected_segment]['CustomerID'].tolist()
                    tx_df = tx_df[tx_df['CustomerID'].isin(segment_ids)]

            # Apply DATE Filter
            if calculated_dates and calculated_dates.get('start_date') and calculated_dates.get('end_date'):
                start = pd.to_datetime(calculated_dates.get('start_date'))
                end = pd.to_datetime(calculated_dates.get('end_date'))
                tx_df = tx_df[(tx_df['InvoiceDate'] >= start) & (tx_df['InvoiceDate'] <= end)]
            
            if len(tx_df) == 0:
                return go.Figure().add_annotation(text='No data for selected filters', showarrow=False)
            
            # Determine granularity and formatting based on selected period
            if selected_period in ['last_7', 'last_14', 'last_30']:
                # DAILY MODE: Show every day with explicit Day, Month, Year
                trend_data = tx_df.set_index('InvoiceDate').resample('D')['Amount'].sum().reset_index()
                trend_data = trend_data[trend_data['Amount'] > 0]  # Remove zero-amount days
                
                # X-Axis formatting
                tickformat = '%d %b %Y'  # e.g., "05 Jan 2011"
                dtick = 'D1'              # Tick mark for every day
                tickmode = 'linear'       # Force linear mode to show all labels
                xlabel = 'Date'
                hover_format = '%d %b %Y'  # e.g., "05 Jan 2011"
            else:
                # MONTHLY MODE: Aggregate by month START (MS) instead of month END (M)
                # This ensures data points align perfectly with X-axis labels
                trend_data = tx_df.set_index('InvoiceDate').resample('MS')['Amount'].sum().reset_index()
                
                # X-Axis formatting
                tickformat = '%b %Y'      # e.g., "Jan 2011"
                dtick = 'M1'              # Tick mark for every month
                tickmode = 'linear'       # Force linear mode to show all labels
                xlabel = 'Month'
                hover_format = '%b %Y'    # e.g., "Jan 2011"
                
            trend_data.columns = ['Date', 'Amount']

            fig = go.Figure(data=[go.Scatter(
                x=trend_data['Date'],
                y=trend_data['Amount'],
                mode='lines+markers',
                name='Revenue',
                line=dict(color='#667eea', width=3),
                marker=dict(size=8),
                fill='tozeroy',
                hovertemplate='<b>%{x|' + hover_format + '}</b><br>£%{y:,.2f}<extra></extra>'
            )])
            
            fig.update_layout(
                title='Sales Trend',
                xaxis_title=xlabel,
                yaxis_title='Revenue (£)',
                height=350,
                paper_bgcolor='#fff',
                hovermode='x unified',
                xaxis=dict(
                    tickformat=tickformat,
                    dtick=dtick,
                    tickmode=tickmode  # Force linear mode to show all labels
                )
            )
            return fig
        except Exception as e:
            logger.error(f"[TREND] Error: {e}")
            return go.Figure().add_annotation(text=f'Error: {str(e)}', showarrow=False)
    
    @app.callback(
        Output('exec-sales-heatmap', 'figure'),
        [Input('transaction-data-store', 'data'),
         Input('calculated-dates-store', 'data'),
         Input('global-segment-filter', 'value'),
         Input('rfm-data-store', 'data')],
        prevent_initial_call=False
    )
    def update_exec_sales_heatmap(tx_data, calculated_dates, selected_segment, rfm_data):
        """Update Heatmap with correct Segment Filtering."""
        try:
            if not tx_data: return go.Figure().add_annotation(text='No data', showarrow=False)
            
            tx_df = pd.read_json(tx_data)
            tx_df['InvoiceDate'] = pd.to_datetime(tx_df['InvoiceDate'], errors='coerce')
            
            # FIX: Robust ID & Segment Filter
            if selected_segment != 'All' and rfm_data:
                rfm_df = pd.read_json(rfm_data)
                rfm_df['CustomerID'] = rfm_df['CustomerID'].astype(str).str.split('.').str[0]
                if 'CustomerID' in tx_df.columns:
                    tx_df['CustomerID'] = tx_df['CustomerID'].astype(str).str.split('.').str[0]
                    segment_ids = rfm_df[rfm_df['Segment'] == selected_segment]['CustomerID'].tolist()
                    tx_df = tx_df[tx_df['CustomerID'].isin(segment_ids)]

            # Apply Date Filter
            if calculated_dates and calculated_dates.get('start_date') and calculated_dates.get('end_date'):
                start = pd.to_datetime(calculated_dates.get('start_date'))
                end = pd.to_datetime(calculated_dates.get('end_date'))
                tx_df = tx_df[(tx_df['InvoiceDate'] >= start) & (tx_df['InvoiceDate'] <= end)]
            
            if len(tx_df) == 0: return go.Figure().add_annotation(text='No data', showarrow=False)
            
            # Generate Heatmap
            tx_df['DayOfWeek'] = tx_df['InvoiceDate'].dt.dayofweek
            tx_df['Hour'] = tx_df['InvoiceDate'].dt.hour
            heatmap = tx_df.groupby(['DayOfWeek', 'Hour']).size().reset_index(name='Count')
            
            heatmap_matrix = np.zeros((7, 24))
            for _, row in heatmap.iterrows(): heatmap_matrix[int(row['DayOfWeek']), int(row['Hour'])] = row['Count']
            
            fig = go.Figure(data=go.Heatmap(z=heatmap_matrix, x=[f'{h:02d}:00' for h in range(24)], 
                                          y=['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], 
                                          colorscale='RdYlGn'))
            fig.update_layout(title='Golden Hours', height=350, paper_bgcolor='#fff')
            return fig
        except Exception as e: return go.Figure().add_annotation(text=f'Error: {e}', showarrow=False)

    @app.callback(
        Output('exec-top-5-products', 'figure'),
        [Input('transaction-data-store', 'data'),
         Input('calculated-dates-store', 'data'),
         Input('global-segment-filter', 'value'),
         Input('rfm-data-store', 'data')],
        prevent_initial_call=False
    )
    def update_exec_top_5(tx_data, calculated_dates, selected_segment, rfm_data):
        """Update Top 5 Products with correct Segment Filtering."""
        try:
            if not tx_data: return go.Figure().add_annotation(text='No data', showarrow=False)
            
            tx_df = pd.read_json(tx_data)
            tx_df['InvoiceDate'] = pd.to_datetime(tx_df['InvoiceDate'], errors='coerce')
            
            # FIX: Robust ID & Segment Filter
            if selected_segment != 'All' and rfm_data:
                rfm_df = pd.read_json(rfm_data)
                rfm_df['CustomerID'] = rfm_df['CustomerID'].astype(str).str.split('.').str[0]
                if 'CustomerID' in tx_df.columns:
                    tx_df['CustomerID'] = tx_df['CustomerID'].astype(str).str.split('.').str[0]
                    segment_ids = rfm_df[rfm_df['Segment'] == selected_segment]['CustomerID'].tolist()
                    tx_df = tx_df[tx_df['CustomerID'].isin(segment_ids)]

            # Apply Date Filter
            if calculated_dates and calculated_dates.get('start_date') and calculated_dates.get('end_date'):
                start = pd.to_datetime(calculated_dates.get('start_date'))
                end = pd.to_datetime(calculated_dates.get('end_date'))
                tx_df = tx_df[(tx_df['InvoiceDate'] >= start) & (tx_df['InvoiceDate'] <= end)]
            
            if len(tx_df) == 0: return go.Figure().add_annotation(text='No data', showarrow=False)
            
            # Generate Top 5
            top5 = prepare_top_products(tx_df, n=5)
            if len(top5) == 0: return go.Figure().add_annotation(text='No products', showarrow=False)
            
            top5 = top5.rename(columns={'Product': 'Description', 'Total_Quantity': 'Quantity', 'Total_Revenue': 'Amount'})
            
            fig = go.Figure(data=[go.Bar(x=top5['Quantity'], y=top5['Description'], orientation='h', marker=dict(color='#51cf66'),
                                       text=[f"Qty: {int(q)}" for q in top5['Quantity']], textposition='outside',
                                       hovertemplate='<b>%{y}</b><br>Quantity: %{x}<br>Revenue: £%{customdata:,.2f}<extra></extra>',
                                       customdata=top5['Amount'].values)])
            fig.update_layout(title='Top 5 Best Sellers', xaxis_title='Quantity Sold', height=300, margin=dict(l=250), 
                              paper_bgcolor='#fff', showlegend=False)
            return fig
        except Exception as e: return go.Figure().add_annotation(text='Error', showarrow=False)
    
    # ===== TAB 2: CUSTOMER SEGMENTATION CALLBACKS =====
    
    @app.callback(
        Output('segment-3d-rfm', 'figure'),
        Input('rfm-data-store', 'data'),
        prevent_initial_call=False
    )
    def update_segment_3d_rfm(rfm_data):
        """Update 3D RFM scatter for customer segmentation (shows all clusters)."""
        try:
            if not rfm_data:
                fig = go.Figure()
                fig.add_annotation(text='No data available', showarrow=False)
                return fig
            
            rfm_df = pd.read_json(rfm_data)
            
            # Remove outliers
            rfm_clean = rfm_df.copy()
            for col in ['Recency', 'Frequency', 'Monetary']:
                p5 = rfm_clean[col].quantile(0.05)
                p95 = rfm_clean[col].quantile(0.95)
                rfm_clean = rfm_clean[(rfm_clean[col] >= p5) & (rfm_clean[col] <= p95)]
            
            rfm_clean = rfm_clean[(rfm_clean['Frequency'] >= 1) & (rfm_clean['Monetary'] >= 10)]
            
            segment_colors = {
                'High Value': '#51cf66',
                'Mid Value': '#4dabf7',
                'Low Value': '#ffd43b',
                'At Risk': '#ff6b6b'
            }
            
            fig = go.Figure(data=[go.Scatter3d(
                x=rfm_clean['Recency'],
                y=rfm_clean['Frequency'],
                z=rfm_clean['Monetary'],
                mode='markers',
                marker=dict(
                    size=5,
                    color=[segment_colors.get(seg, '#667eea') for seg in rfm_clean['Segment']],
                    opacity=0.7,
                    line=dict(width=0)
                ),
                text=[f"R:{r} F:{f} M:${m:.0f} Seg:{s}"
                      for r, f, m, s in zip(rfm_clean['Recency'], rfm_clean['Frequency'], 
                                           rfm_clean['Monetary'], rfm_clean['Segment'])],
                hovertemplate='%{text}<extra></extra>'
            )])
            
            fig.update_layout(
                title=f'3D RFM Customer Space ({len(rfm_clean)} customers)',
                scene=dict(
                    xaxis_title='Recency (days)',
                    yaxis_title='Frequency',
                    zaxis_title='Monetary ($)',
                    camera=dict(eye=dict(x=1.5, y=1.5, z=1.3))
                ),
                height=450,
                paper_bgcolor='#fff',
                showlegend=False
            )
            return fig
        except Exception as e:
            logger.error(f"[DASHBOARD] Error in 3D RFM: {e}")
            return go.Figure().add_annotation(text=f'Error: {str(e)}', showarrow=False)
    
    @app.callback(
        Output('segment-group-profile', 'figure'),
        Input('rfm-data-store', 'data'),
        prevent_initial_call=False
    )
    def update_segment_group_profile(rfm_data):
        """Update group profile comparison chart."""
        try:
            if not rfm_data:
                fig = go.Figure()
                fig.add_annotation(text='No data available', showarrow=False)
                return fig
            
            rfm_df = pd.read_json(rfm_data)
            
            # Calculate group stats
            group_stats = rfm_df.groupby('Segment').agg({
                'Recency': 'mean',
                'Frequency': 'mean',
                'Monetary': 'mean'
            }).reset_index()
            
            # Normalize for comparison
            for col in ['Recency', 'Frequency', 'Monetary']:
                max_val = group_stats[col].max()
                if col == 'Recency':
                    group_stats[f'{col}_norm'] = (1 - group_stats[col] / max_val) * 100 if max_val > 0 else 0
                else:
                    group_stats[f'{col}_norm'] = (group_stats[col] / max_val) * 100 if max_val > 0 else 0
            
            fig = go.Figure()
            
            for idx, (_, row) in enumerate(group_stats.iterrows()):
                fig.add_trace(go.Bar(
                    name=row['Segment'],
                    x=['Recency (Inverse)', 'Frequency', 'Monetary'],
                    y=[row['Recency_norm'], row['Frequency_norm'], row['Monetary_norm']],
                    text=[f"{row['Recency_norm']:.0f}", f"{row['Frequency_norm']:.0f}", f"{row['Monetary_norm']:.0f}"],
                    textposition='auto',
                    hovertemplate='<b>%{name}</b><br>%{x}: %{y:.0f}<extra></extra>'
                ))
            
            fig.update_layout(
                title='Customer Segment Profiles (Normalized 0-100)',
                barmode='group',
                xaxis_title='RFM Metrics',
                yaxis_title='Normalized Score',
                height=450,
                paper_bgcolor='#fff',
                hovermode='x unified'
            )
            return fig
        except Exception as e:
            logger.error(f"[DASHBOARD] Error in group profile: {e}")
            return go.Figure().add_annotation(text=f'Error: {str(e)}', showarrow=False)
    
    @app.callback(
        Output('local-segment-top-countries', 'figure'),
        [Input('transaction-data-store', 'data'),
         Input('local-segment-filter', 'value'),
         Input('rfm-data-store', 'data')],
        prevent_initial_call=False
    )
    def update_local_segment_top_countries(tx_data, local_segment, rfm_data):
        """Update Top 5 Countries chart with Robust ID Matching."""
        try:
            if not tx_data:
                return go.Figure().add_annotation(text='No data available', showarrow=False)
            
            tx_df = pd.read_json(tx_data)
            
            # KEY FIX: Force CustomerID to string to fix "No Data" bug
            if 'CustomerID' in tx_df.columns:
                tx_df['CustomerID'] = tx_df['CustomerID'].astype(str).str.split('.').str[0]
            
            # Apply Local Segment Filter
            if local_segment and local_segment != 'All' and rfm_data:
                rfm_df = pd.read_json(rfm_data)
                
                # KEY FIX: Force RFM IDs to string to match Transaction IDs
                rfm_df['CustomerID'] = rfm_df['CustomerID'].astype(str).str.split('.').str[0]
                
                # Get IDs for this segment
                segment_customers = rfm_df[rfm_df['Segment'] == local_segment]['CustomerID'].tolist()
                
                # Filter Transactions
                tx_df = tx_df[tx_df['CustomerID'].isin(segment_customers)]
            
            if len(tx_df) == 0:
                return go.Figure().add_annotation(text='No transactions for this segment', showarrow=False)
            
            # Group and Plot
            countries = tx_df.groupby('Country').agg({'Amount': 'sum'}).reset_index()
            countries = countries.nlargest(5, 'Amount').sort_values('Amount', ascending=True)
            
            fig = go.Figure(data=[
                go.Bar(
                    x=countries['Amount'],
                    y=countries['Country'],
                    orientation='h',
                    marker=dict(color='#4dabf7'),
                    text=[f"£{x:,.0f}" for x in countries['Amount']],
                    textposition='outside',
                    hovertemplate='<b>%{y}</b><br>Revenue: £%{x:,.2f}<extra></extra>'
                )
            ])
            
            fig.update_layout(
                title=f'Top 5 Countries ({local_segment if local_segment else "All"})',
                xaxis_title='Revenue (£)',
                height=450,
                margin=dict(l=100),
                paper_bgcolor='#fff',
                showlegend=False
            )
            return fig
        except Exception as e:
            logger.error(f"[TOP-COUNTRIES] Error: {e}")
            return go.Figure().add_annotation(text=f'Error: {str(e)}', showarrow=False)
    
    @app.callback(
        Output('segment-top-countries', 'figure'),
        [Input('transaction-data-store', 'data'),
         Input('calculated-dates-store', 'data'),
         Input('global-segment-filter', 'value')],
        prevent_initial_call=False
    )
    def update_segment_top_countries(tx_data, calculated_dates, segment):
        """Update Top 5 Countries chart for customer segmentation (old - kept for backward compatibility)."""
        try:
            if not tx_data:
                fig = go.Figure()
                fig.add_annotation(text='No data available', showarrow=False)
                return fig
            
            tx_df = pd.read_json(tx_data)
            tx_df['InvoiceDate'] = pd.to_datetime(tx_df['InvoiceDate'], errors='coerce')
            
            # Apply date filters
            if calculated_dates and calculated_dates.get('start_date') and calculated_dates.get('end_date'):
                start = pd.to_datetime(calculated_dates.get('start_date'))
                end = pd.to_datetime(calculated_dates.get('end_date'))
                tx_df = tx_df[(tx_df['InvoiceDate'] >= start) & (tx_df['InvoiceDate'] <= end)]
            
            # Apply segment filter
            if segment and segment != 'All':
                tx_df = tx_df[tx_df['Segment'] == segment]
            
            # Check if data is empty
            if len(tx_df) == 0:
                fig = go.Figure()
                fig.add_annotation(text='No data available for selected filters', showarrow=False)
                return fig
            
            # Get top 5 countries by revenue
            countries = tx_df.groupby('Country').agg({'Amount': 'sum'}).reset_index()
            countries = countries.nlargest(5, 'Amount')
            
            if len(countries) == 0:
                fig = go.Figure()
                fig.add_annotation(text='No country data available', showarrow=False)
                return fig
            
            fig = go.Figure(data=[
                go.Bar(
                    x=countries['Amount'],
                    y=countries['Country'],
                    orientation='h',
                    marker=dict(color='#4dabf7'),
                    text=[f"£{x:,.0f}" for x in countries['Amount']],
                    textposition='outside',
                    hovertemplate='<b>%{y}</b><br>Revenue: £%{x:,.2f}<extra></extra>'
                )
            ])
            
            fig.update_layout(
                title='Top 5 Countries by Revenue',
                xaxis_title='Revenue (£)',
                height=450,
                margin=dict(l=100),
                paper_bgcolor='#fff',
                showlegend=False
            )
            return fig
        except Exception as e:
            logger.error(f"[DASHBOARD] Error in top countries: {e}")
            return go.Figure().add_annotation(text=f'Error: {str(e)}', showarrow=False)
    
    @app.callback(
        Output('download-customer-list', 'data'),
        Input('download-customer-list-btn', 'n_clicks'),
        [State('rfm-data-store', 'data'),
         State('global-segment-filter', 'value')],
        prevent_initial_call=True
    )
    def download_customer_list(n_clicks, rfm_data, selected_segment):
        """Download customer list as CSV."""
        try:
            if not rfm_data or n_clicks == 0:
                return no_update
            
            rfm_df = pd.read_json(rfm_data)
            
            # Filter by segment
            if selected_segment != 'All':
                rfm_df = rfm_df[rfm_df['Segment'] == selected_segment]
            
            if len(rfm_df) == 0:
                return no_update
            
            # Prepare download data
            download_df = rfm_df[[
                'CustomerID', 'Segment', 'Recency', 'Frequency', 'Monetary'
            ]].copy()
            download_df.columns = ['Customer ID', 'Segment', 'Recency (Days)', 'Frequency', 'Monetary Value (£)']
            
            # Return CSV download
            return dcc.send_data_frame(download_df.to_csv, filename='customer_list.csv', index=False)
        except Exception as e:
            logger.error(f"[DOWNLOAD] Error downloading customer list: {e}")
            return no_update
    
    # ===== LOCAL SEGMENT CALLBACKS FOR TAB 2 (Customer Segmentation) =====
    
    @app.callback(
        Output('local-segment-customer-table', 'children'),
        [Input('rfm-data-store', 'data'),
         Input('local-segment-filter', 'value')],
        prevent_initial_call=False
    )
    def update_local_segment_customer_table(rfm_data, local_segment):
        """Update customer table using LOCAL segment filter (Tab 2). Shows top 20 High Value Customers."""
        try:
            if not rfm_data:
                return html.Div('No customer data available', style={'padding': '20px', 'textAlign': 'center', 'color': '#999'})
            
            rfm_df = pd.read_json(rfm_data)
            
            # Apply LOCAL segment filter
            if local_segment and local_segment != 'All':
                rfm_df = rfm_df[rfm_df['Segment'] == local_segment]
            
            if len(rfm_df) == 0:
                return html.Div(f'No customers found in {local_segment} segment', 
                               style={'padding': '20px', 'textAlign': 'center', 'color': '#999'})
            
            # ✅ CHANGE 3: Sort by Monetary (descending) and keep only top 20
            rfm_df = rfm_df.sort_values('Monetary', ascending=False).head(20)
            
            # Prepare table
            display_cols = ['CustomerID', 'Segment', 'Recency', 'Frequency', 'Monetary']
            if not all(col in rfm_df.columns for col in display_cols):
                return html.Div('Missing required columns', style={'padding': '20px', 'textAlign': 'center', 'color': '#d32f2f'})
            
            table_df = rfm_df[display_cols].copy()
            table_df.columns = ['Customer ID', 'Segment', 'Recency (Days)', 'Frequency', 'Monetary Value (£)']
            
            # Create table HTML
            table_rows = [
                html.Tr([
                    html.Th(col, style={'padding': '10px', 'borderBottom': '2px solid #667eea', 'textAlign': 'left', 'fontWeight': 'bold'})
                    for col in table_df.columns
                ])
            ]
            
            for _, row in table_df.iterrows():
                table_rows.append(
                    html.Tr([
                        html.Td(str(val), style={'padding': '10px', 'borderBottom': '1px solid #ddd'})
                        for val in row
                    ])
                )
            
            # Create table with note about top 20 limit
            return html.Div([
                html.Table(table_rows, style={'width': '100%', 'borderCollapse': 'collapse', 'fontSize': '13px'}),
                html.P(
                    '📌 Showing top 20 High Value Customers (sorted by Monetary Value). Use "Download CSV" for full list.',
                    style={'marginTop': '15px', 'padding': '10px', 'backgroundColor': '#f0f4ff', 'borderRadius': '4px', 
                           'fontSize': '12px', 'color': '#667eea', 'fontStyle': 'italic', 'borderLeft': '3px solid #667eea'}
                )
            ])
        except Exception as e:
            logger.error(f"[LOCAL-TABLE] Error updating customer table: {e}")
            return html.Div(f'Error: {str(e)}', style={'padding': '20px', 'color': '#d32f2f'})
    
    @app.callback(
        Output('local-download-customer-list', 'data'),
        Input('local-download-customer-list-btn', 'n_clicks'),
        [State('rfm-data-store', 'data'),
         State('local-segment-filter', 'value')],
        prevent_initial_call=True
    )
    def local_download_customer_list(n_clicks, rfm_data, local_segment):
        """Download customer list as CSV using LOCAL segment filter."""
        try:
            if not rfm_data or n_clicks == 0:
                return no_update
            
            rfm_df = pd.read_json(rfm_data)
            
            # Filter by LOCAL segment
            if local_segment and local_segment != 'All':
                rfm_df = rfm_df[rfm_df['Segment'] == local_segment]
            
            if len(rfm_df) == 0:
                return no_update
            
            # Prepare download data
            download_df = rfm_df[[
                'CustomerID', 'Segment', 'Recency', 'Frequency', 'Monetary'
            ]].copy()
            download_df.columns = ['Customer ID', 'Segment', 'Recency (Days)', 'Frequency', 'Monetary Value (£)']
            
            logger.info(f"[LOCAL-DOWNLOAD] Downloading {len(download_df)} customers from {local_segment} segment")
            
            # Return CSV download
            return dcc.send_data_frame(download_df.to_csv, filename='customer_list.csv', index=False)
        except Exception as e:
            logger.error(f"[LOCAL-DOWNLOAD] Error downloading customer list: {e}")
            return no_update
    
    @app.callback(
        Output('customer-list-modal', 'is_open'),
        [Input('local-expand-customer-list-btn', 'n_clicks'),
         Input('close-modal-btn', 'n_clicks')],
        State('customer-list-modal', 'is_open'),
        prevent_initial_call=False
    )
    def toggle_customer_list_modal(expand_clicks, close_clicks, is_open):
        """Toggle modal visibility for expanded customer list view."""
        if expand_clicks or close_clicks:
            return not is_open
        return is_open
    
    @app.callback(
        Output('modal-customer-table', 'children'),
        [Input('rfm-data-store', 'data'),
         Input('local-segment-filter', 'value'),
         Input('customer-list-modal', 'is_open')],
        prevent_initial_call=False
    )
    def update_modal_customer_table(rfm_data, local_segment, is_open):
        """Update the expanded customer table in modal using LOCAL segment filter."""
        try:
            if not is_open or not rfm_data:
                return html.Div('No data', style={'padding': '20px'})
            
            rfm_df = pd.read_json(rfm_data)
            
            # Apply LOCAL segment filter
            if local_segment and local_segment != 'All':
                rfm_df = rfm_df[rfm_df['Segment'] == local_segment]
            
            if len(rfm_df) == 0:
                return html.Div(f'No customers in {local_segment} segment', 
                               style={'padding': '20px', 'textAlign': 'center', 'color': '#999'})
            
            # Prepare table
            display_cols = ['CustomerID', 'Segment', 'Recency', 'Frequency', 'Monetary']
            table_df = rfm_df[display_cols].copy()
            table_df.columns = ['Customer ID', 'Segment', 'Recency (Days)', 'Frequency', 'Monetary Value (£)']
            
            # Create table HTML for modal (scrollable)
            table_rows = [
                html.Tr([
                    html.Th(col, style={'padding': '12px', 'borderBottom': '2px solid #667eea', 'textAlign': 'left', 'fontWeight': 'bold', 'backgroundColor': '#f9f9f9'})
                    for col in table_df.columns
                ])
            ]
            
            for _, row in table_df.iterrows():
                table_rows.append(
                    html.Tr([
                        html.Td(str(val), style={'padding': '12px', 'borderBottom': '1px solid #ddd'})
                        for val in row
                    ])
                )
            
            return html.Table(table_rows, style={'width': '100%', 'borderCollapse': 'collapse', 'fontSize': '14px'})
        except Exception as e:
            logger.error(f"[MODAL-TABLE] Error updating modal table: {e}")
            return html.Div(f'Error: {str(e)}', style={'padding': '20px', 'color': '#d32f2f'})

# =============================================
# PARETO ANALYSIS CALLBACKS (Product Portfolio)
# =============================================

    @app.callback(
        [Output('pareto-chart', 'figure'),
         Output('core-products-table', 'children')],
        [Input('transaction-data-store', 'data'),
         Input('calculated-dates-store', 'data'),
         Input('global-segment-filter', 'value'),
         Input('rfm-data-store', 'data')],
        prevent_initial_call=False
    )
    def update_pareto_analysis(tx_data, calculated_dates, selected_segment, rfm_data):
        """Update Pareto chart showing product contribution with dual filtering."""
        try:
            # Debug logging
            logger.info(f"[PARETO] Callback triggered - tx_data={bool(tx_data)}, dates={bool(calculated_dates)}, segment={selected_segment}")
            
            if not tx_data:
                logger.warning("[PARETO] ❌ No transaction data - user must upload data first")
                return (
                    go.Figure().add_annotation(
                        text='📊 No Data Available<br><br>⬅️ Please click "Back to Upload Dataset" and upload your sales data.',
                        showarrow=False,
                        font=dict(size=16, color='#999')
                    ).update_layout(height=600, paper_bgcolor='#fff'),
                    html.Div(
                        '❌ No data uploaded yet. Please go back and upload your sales file.',
                        style={'padding': '20px', 'textAlign': 'center', 'color': '#d32f2f', 'fontSize': '14px', 'fontWeight': 'bold'}
                    )
                )
            
            logger.info("[PARETO] ✅ Transaction data found - processing...")
            
            # Parse JSON transaction data
            tx_df = pd.read_json(tx_data)
            tx_df['InvoiceDate'] = pd.to_datetime(tx_df['InvoiceDate'], errors='coerce')
            
            # STEP 1: Apply Date Filter FIRST
            if calculated_dates and calculated_dates.get('start_date') and calculated_dates.get('end_date'):
                try:
                    start = pd.to_datetime(calculated_dates.get('start_date'))
                    end = pd.to_datetime(calculated_dates.get('end_date'))
                    tx_df = tx_df[(tx_df['InvoiceDate'] >= start) & (tx_df['InvoiceDate'] <= end)]
                    logger.info(f"[PARETO] Applied date filter: {start.date()} to {end.date()}, rows left: {len(tx_df)}")
                except Exception as e:
                    logger.warning(f"[PARETO] Could not apply date filter: {e}, using all data")
            
            # STEP 2: Apply Segment Filter SECOND (using RFM data)
            if selected_segment and selected_segment != 'All' and rfm_data:
                try:
                    rfm_df = pd.read_json(rfm_data)
                    # KEY FIX: Convert CustomerID to string to match transaction data
                    rfm_df['CustomerID'] = rfm_df['CustomerID'].astype(str).str.split('.').str[0]
                    tx_df['CustomerID'] = tx_df['CustomerID'].astype(str).str.split('.').str[0]
                    segment_customers = rfm_df[rfm_df['Segment'] == selected_segment]['CustomerID'].tolist()
                    initial_count = len(tx_df)
                    tx_df = tx_df[tx_df['CustomerID'].isin(segment_customers)]
                    logger.info(f"[PARETO] Applied segment filter '{selected_segment}': {initial_count} → {len(tx_df)} rows")
                except Exception as seg_err:
                    logger.warning(f"[PARETO] Could not apply segment filter: {seg_err}")
            
            # CRASH PREVENTION: Check if filtered result is empty
            if len(tx_df) == 0:
                logger.warning("[PARETO] ⚠️ No transaction data after filtering - returning placeholder")
                no_data_fig = go.Figure().add_annotation(
                    text='📊 No Data for Selected Filters<br><br>Try selecting a different date range or segment.',
                    showarrow=False,
                    font=dict(size=16, color='#999')
                ).update_layout(height=600, paper_bgcolor='#fff')
                
                no_data_text = html.Div(
                    f'No data available for {selected_segment} in the selected period',
                    style={'color': '#999', 'padding': '20px', 'textAlign': 'center', 'fontWeight': '500'}
                )
                return no_data_fig, no_data_text
            
            # Prepare pareto analysis
            pareto_df = prepare_pareto_analysis(tx_df)
            logger.info(f"[PARETO] Pareto DF created with {len(pareto_df)} products")
            
            # Get top 20 products for chart
            top_products = pareto_df.head(20)
            if len(top_products) == 0:
                logger.warning("[PARETO] No products found")
                return (
                    go.Figure().add_annotation(
                        text='📊 No Products Available<br><br>Check your data.',
                        showarrow=False,
                        font=dict(size=16, color='#999')
                    ).update_layout(height=600, paper_bgcolor='#fff'),
                    html.Div('No products available', style={'color': '#999', 'padding': '20px', 'textAlign': 'center'})
                )
            
            # Create dual-axis figure
            fig = go.Figure()
            
            # Create percentage string array for hover (outside trace definition)
            pct_strs = top_products['Percentage'].astype(str).values
            
            # Add bar chart for individual product revenue
            fig.add_trace(go.Bar(
                x=top_products['Description'].values,
                y=top_products['Amount'].values,
                name='Product Revenue',
                marker=dict(color='#667eea'),
                yaxis='y',
                customdata=pct_strs,
                hovertemplate='<b>%{x}</b><br>Revenue: £%{y:,.2f}<br>Share: %{customdata}%<extra></extra>'
            ))
            
            # Add line chart for cumulative percentage
            fig.add_trace(go.Scatter(
                x=top_products['Description'].values,
                y=top_products['Cumulative_Percentage'].values,
                name='Cumulative %',
                line=dict(color='#ff6b6b', width=3),
                yaxis='y2',
                mode='lines+markers',
                marker=dict(size=8),
                hovertemplate='<b>%{x}</b><br>Cumulative: %{y:.1f}%<extra></extra>'
            ))
            
            # Add 80% reference line
            fig.add_hline(y=80, line_dash='dash', line_color='#4caf50', 
                         annotation_text='80% Threshold', annotation_position='right',
                         yref='y2')
            
            fig.update_layout(
                title='Top 20 Products by Revenue Contribution (Pareto Analysis)',
                xaxis=dict(title='Product', tickangle=-45),
                yaxis=dict(
                    title=dict(text='Revenue (£)', font=dict(color='#667eea')),
                    tickfont=dict(color='#667eea')
                ),
                yaxis2=dict(
                    title=dict(text='Cumulative %', font=dict(color='#ff6b6b')),
                    tickfont=dict(color='#ff6b6b'),
                    overlaying='y',
                    side='right'
                ),
                hovermode='x unified',
                height=600,
                showlegend=True,
                legend=dict(x=0.02, y=0.98),
                paper_bgcolor='#fff',
                plot_bgcolor='#f9f9f9'
            )
            
            # Get core products (those contributing to 80%)
            core_products = pareto_df[pareto_df['Cumulative_Percentage'] <= 80]
            logger.info(f"[PARETO] Core products (80% threshold): {len(core_products)} products")
            
            # Create table for core products
            if len(core_products) > 0:
                table_rows = []
                for idx, row in core_products.head(15).iterrows():
                    try:
                        table_rows.append(html.Tr([
                            html.Td(f"#{int(row['Rank'])}", style={'padding': '8px', 'borderBottom': '1px solid #eee', 'fontWeight': 'bold'}),
                            html.Td(str(row['Description'])[:50], style={'padding': '8px', 'borderBottom': '1px solid #eee'}),
                            html.Td(f"£{float(row['Amount']):,.2f}", style={'padding': '8px', 'borderBottom': '1px solid #eee', 'textAlign': 'right'}),
                            html.Td(f"{float(row['Percentage']):.1f}%", style={'padding': '8px', 'borderBottom': '1px solid #eee', 'textAlign': 'right'}),
                            html.Td(f"{float(row['Cumulative_Percentage']):.1f}%", style={'padding': '8px', 'borderBottom': '1px solid #eee', 'textAlign': 'right', 'color': '#667eea', 'fontWeight': 'bold'}),
                        ]))
                    except Exception as row_err:
                        logger.error(f"[PARETO] Error processing row {idx}: {row_err}")
                
                if len(table_rows) > 0:
                    table = html.Table([
                        html.Thead(html.Tr([
                            html.Th('Rank', style={'padding': '10px', 'textAlign': 'left', 'borderBottom': '2px solid #667eea', 'fontWeight': 'bold', 'backgroundColor': '#f0f0f0'}),
                            html.Th('Product', style={'padding': '10px', 'textAlign': 'left', 'borderBottom': '2px solid #667eea', 'fontWeight': 'bold', 'backgroundColor': '#f0f0f0'}),
                            html.Th('Revenue', style={'padding': '10px', 'textAlign': 'right', 'borderBottom': '2px solid #667eea', 'fontWeight': 'bold', 'backgroundColor': '#f0f0f0'}),
                            html.Th('Share %', style={'padding': '10px', 'textAlign': 'right', 'borderBottom': '2px solid #667eea', 'fontWeight': 'bold', 'backgroundColor': '#f0f0f0'}),
                            html.Th('Cumulative %', style={'padding': '10px', 'textAlign': 'right', 'borderBottom': '2px solid #667eea', 'fontWeight': 'bold', 'backgroundColor': '#f0f0f0'}),
                        ])),
                        html.Tbody(table_rows)
                    ], style={'width': '100%', 'borderCollapse': 'collapse', 'fontSize': '12px'})
                    
                    total_revenue = float(core_products['Amount'].sum())
                    total_all_revenue = float(pareto_df['Amount'].sum())
                    info = html.Div([
                        html.P(f"📊 Top {len(core_products)} products contribute 80% of total revenue (£{total_revenue:,.2f} / £{total_all_revenue:,.2f})",
                              style={'color': '#667eea', 'fontWeight': 'bold', 'marginBottom': '15px'}),
                        table
                    ])
                else:
                    info = html.Div('No products in 80% threshold', style={'color': '#999', 'padding': '20px'})
            else:
                info = html.Div('No products in 80% threshold', style={'color': '#999', 'padding': '20px'})
            
            return fig, info
        except Exception as e:
            logger.error(f"[PARETO] Error in pareto analysis: {e}")
            return go.Figure().add_annotation(text=f'Error: {str(e)}', showarrow=False), html.Div(f'Error: {str(e)}')