================================================================================
                 E-COMMERCE RFM ANALYTICS PLATFORM
================================================================================
Project Name:   E-COMMERCE SALES AND CUSTOMER DASHBOARD FOR PERFORMANCE ANALYSIS
Project ID:     T86Q952
Student:        CHAN HUI QI (1211103848)
Programme:      Bachelor of Information Technology (Hons) Business Intelligence and Analytics (BIA)
Faculty:        Faculty of Information Science and Technology, Multimedia University
Session:        2025/2026 (Phase 1: Oct/Nov 2024/2025; Phase 2: Oct/Nov 2025)
Supervisor:     Dr. Leow Meng Chew
Description:    This project entails the design and development of an interactive web-based dashboard to help e-commerce businesses analyze their vast transactional data for improved decision-making. The core of the dashboard is the implementation of the RFM (Recency, Frequency, Monetary) model, which will be used to segment customers into actionable groups for targeted marketing strategies aimed at enhancing customer loyalty and retention. The entire application will be built using Python for backend data processing and the Plotly Dash framework for the interactive front-end user interface, utilizing a sample dataset for development and validation.
Objectives:     
1. To investigate key performance indicators (KPIs) in e-commerce and research established customer segmentation models, with a focus on RFM analysis.
2. To design a conceptual framework for a visual analytics dashboard that integrates both sales performance metrics and customer segmentation views.

================================================================================
                              SYSTEM REQUIREMENTS
================================================================================

Python Version: Python 3.12+
Download from: https://www.python.org/downloads/

Operating System: Windows, macOS, or Linux
RAM: Minimum 4GB (8GB recommended for smooth performance)
Internet Connection: Required for initial setup and PyPI package downloads

================================================================================
                           INSTALLATION INSTRUCTIONS
================================================================================

STEP 1: Install Python
1. Download Python from: https://www.python.org/downloads/
2. Choose Python 3.12.x or higher
3. During installation, CHECK the box: "Add Python to PATH"
4. Verify installation by opening Command Prompt/Terminal and typing:
   python --version

STEP 2: Install Required Libraries
Navigate to the project directory in Command Prompt/Terminal:
   cd path/to/your/project/folder  (e.g., cd "C:\FYP\Source Code")

Install all dependencies from requirements.txt:
   pip install -r requirements.txt

Or install packages individually:
   pip install pandas==3.0.0
   pip install dash==3.4.0
   pip install dash-bootstrap-components==2.0.4
   pip install scikit-learn==1.5.1
   pip install plotly==5.24.1
   pip install werkzeug==3.0.4
   pip install openpyxl==3.1.5

STEP 3: Verify Installation
Test if packages are installed correctly:
   pip list

You should see all the above packages listed.

================================================================================
                              LIBRARY DETAILS
================================================================================

Package Name                  Version         Purpose
--------                      -------         -------
pandas                        3.0.0+          Data manipulation & analysis
dash                          3.4.0+          Web framework for interactive dashboards
dash-bootstrap-components     2.0.4+          Bootstrap styling for Dash UI
scikit-learn                  1.5.1+          Machine learning (K-means clustering, scaling)
plotly                        5.24.1+         Interactive data visualization
werkzeug                      3.0.4+          Password hashing for user authentication
openpyxl                      3.1.5+          Excel file reading/writing support

================================================================================
                           DATASET INSTRUCTIONS
================================================================================

This project uses the public "Online Retail" dataset for development, testing, and validation.

1. Original Source (Recommended - Most Authoritative):
   - Provider: UCI Machine Learning Repository
   - Download URL: https://archive.ics.uci.edu/dataset/352/online+retail
   - File: Online Retail.xlsx (or unzip to get the data)
   - Citation (for report): Chen, D. (2015). Online Retail [Data set]. UCI Machine Learning Repository. https://doi.org/10.24432/C5BW33
   - Associated Paper: Chen, D., Sain, S. L., & Guo, K. (2012). Data mining for the online retail industry: A case study of RFM model-based customer segmentation using data mining. Journal of Database Marketing & Customer Strategy Management, 19(3), 197–208. https://doi.org/10.1057/dbm.2012.17

2. Alternative Source (Used by Developer):
   - Provider: Kaggle (mirror/uploaded version)
   - Download URL: https://www.kaggle.com/datasets/denisexpsito/uci-machine-learning-online-retail-transactions/data
   - File: Download the CSV/Excel version

3. Usage in This Project:
   - Place the downloaded file in the project root folder as "Sales_Data.xlsx" or "Sales_Data.csv" (a sample CSV is included for quick testing).
   - In the application: After login, go to the upload page and select the file (supports CSV and Excel; columns are automatically standardized).
   - Expected columns (auto-detected): CustomerID, InvoiceDate, Quantity, UnitPrice, Description (variants like 'Price', 'Qty', 'Date' are handled).
   - No preprocessing needed beyond upload—the app cleans, processes RFM, and clusters automatically.

Note: The dataset is public domain / CC BY 4.0 licensed. No self-collected data or private images are used.

================================================================================
                              RUN INSTRUCTIONS
================================================================================

1. Navigate to Project Directory
   cd path/to/your/project/folder

2. (Optional) Create Virtual Environment
   python -m venv venv
   # Activate (Windows):
   venv\Scripts\activate
   # Activate (macOS/Linux):
   source venv/bin/activate

3. Run the Application
   python app.py

4. Access the Dashboard
   Open browser: http://127.0.0.1:8051
   - Register a new user or login with sample credentials from users_database.json (e.g., username: admin, password: check hashed values or use known plain for testing).
   - Upload dataset → View analytics.

5. (Optional) Generate Elbow Plot
   python generate_elbow.py
   → Outputs assets/elbow.png for K-means optimization.

================================================================================
                              FEATURES
================================================================================

1. User Authentication
   - Secure registration/login with password hashing
   - Sample users in users_database.json

2. Data Processing
   - Cleaning, RFM calculation with log transformation
   - K-means clustering (4 segments: High Value, Mid Value, Low Value, At Risk)
   - Scaling and standardization

3. Dashboard
   - Executive overview with KPIs
   - 3D scatter plot of customer segments
   - Sales trends and monthly analysis
   - Top products ranking
   - Customer churn analysis
   - Geographic customer distribution
   - Pareto principle visualization
   - Market basket analysis
   - Interactive filtering by date range

4. Data Upload
   - Support for CSV and Excel formats
   - Automatic column name standardization
   - Data validation and error reporting
   - Flexible column naming

================================================================================
                         PERFORMANCE TIPS
================================================================================

For Large Datasets (>1 million rows):
1. Increase Python memory limit if needed (app handles via pandas optimizations).
2. Close other applications to free RAM.
3. Subset data by date range in the app.
4. Use SSD storage for faster loading.

For Better Responsiveness:
1. Use modern browser (Chrome 120+, Firefox 120+).
2. Limit date filters to 3-6 months.
3. Clear browser cache regularly.

================================================================================
                         ADDITIONAL RESOURCES
================================================================================

Python Documentation:
   https://docs.python.org/3/

Dash Framework Documentation:
   https://dash.plotly.com/

Plotly Visualization:
   https://plotly.com/python/

Scikit-learn Machine Learning:
   https://scikit-learn.org/

RFM Analysis Concepts:
   https://en.wikipedia.org/wiki/RFM_(customer_value)

Online Retail Dataset:
   https://archive.ics.uci.edu/dataset/352/online+retail

================================================================================
                         DEVELOPMENT NOTES
================================================================================

This project is a Final Year Project (FYP Phase 2) demonstrating:
- Full-stack web application development with Python/Dash
- Data science and machine learning (K-means clustering)
- Data visualization and business intelligence
- RESTful API design and callbacks
- User authentication and session management
- Large-scale data processing (500K+ rows)

All code is production-ready and includes:
- Error handling and logging 
- Input validation
- Security best practices (password hashing)
- Performance optimizations
- Comprehensive documentation

For academic use only—do not share sensitive data or deploy publicly without permission.

================================================================================
                        VERSION HISTORY
================================================================================

Version 2.0 (Current - February 2026)
- Redesigned dashboard with 3 main tabs
- K-means clustering with elbow method
- User authentication system
- Custom data upload support
- Enhanced visualizations with Plotly
- Pareto analysis integration
- Market basket analysis
- Performance optimizations for large datasets
