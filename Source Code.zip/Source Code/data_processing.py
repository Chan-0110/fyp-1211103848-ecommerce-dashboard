"""
Data Processing Module
Handles data cleaning, transformation, and RFM analysis with K-means clustering
"""

import pandas as pd
import numpy as np
from datetime import timedelta
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import logging

logger = logging.getLogger(__name__)

# =============================================
# COLUMN STANDARDIZATION MAPPING
# =============================================

COLUMN_MAPPING = {
    'InvoiceDate': ['InvoiceDate', 'Date', 'date', 'order_date', 'OrderDate', 'time'],
    'Quantity': ['Quantity', 'Qty', 'qty', 'Count', 'count', 'OrderQty'],
    'UnitPrice': ['UnitPrice', 'Price', 'price', 'Rate', 'rate', 'Amount', 'amount'],
    'CustomerID': ['CustomerID', 'User_ID', 'user_id', 'Client_ID', 'ID', 'id'],
    'Description': ['Description', 'Product', 'product', 'Item', 'item_name', 'Desc'],
    'InvoiceNo': ['InvoiceNo', 'Order_ID', 'order_id', 'Transaction_ID', 'InvoiceID']
}

# =============================================
# DATA CLEANING & TRANSFORMATION
# =============================================

def standardize_column_names(df):
    """
    Standardize column names by mapping common variations to standard names.
    
    Automatically renames columns based on COLUMN_MAPPING dictionary.
    Performs case-insensitive matching for flexibility.
    
    Parameters:
    - df: Input DataFrame with potentially non-standard column names
    
    Returns:
    - DataFrame with standardized column names
    - Dict of mappings applied (for logging)
    
    Raises:
    - ValueError: If critical columns are missing after standardization
    """
    df_copy = df.copy()
    applied_mappings = {}
    
    # Create a lowercase column mapping for case-insensitive matching
    lowercase_to_original = {col.lower(): col for col in df_copy.columns}
    
    # Try to map each standard column
    for standard_name, variations in COLUMN_MAPPING.items():
        # Skip if already has the standard name
        if standard_name in df_copy.columns:
            continue
        
        # Try each variation (case-insensitive)
        found_match = False
        for variation in variations:
            variation_lower = variation.lower()
            
            # Check if this variation exists (case-insensitive)
            if variation_lower in lowercase_to_original:
                original_col = lowercase_to_original[variation_lower]
                df_copy.rename(columns={original_col: standard_name}, inplace=True)
                applied_mappings[original_col] = standard_name
                logger.info(f"[STANDARDIZE] Renamed '{original_col}' → '{standard_name}'")
                found_match = True
                break
        
        if not found_match and standard_name in ['InvoiceDate', 'Quantity', 'UnitPrice', 'CustomerID']:
            # These are critical columns
            pass  # Will be caught in validation below
    
    return df_copy, applied_mappings

def validate_required_columns(df):
    """
    Validate that all required columns are present.
    
    Parameters:
    - df: DataFrame to validate
    
    Raises:
    - ValueError: If required columns are missing (with friendly message)
    """
    required_columns = ['CustomerID', 'InvoiceDate', 'Quantity', 'UnitPrice']
    missing_columns = [col for col in required_columns if col not in df.columns]
    
    if missing_columns:
        # Provide helpful error message
        available_columns = list(df.columns)
        error_msg = (
            f"❌ Missing required columns after standardization: {', '.join(missing_columns)}\n"
            f"\nAvailable columns in your file: {', '.join(available_columns)}\n"
            f"\nRequired columns (or accepted variations):\n"
        )
        for standard, variations in COLUMN_MAPPING.items():
            if standard in required_columns:
                error_msg += f"  • '{standard}': {', '.join(variations)}\n"
        
        logger.error(f"[VALIDATE] {error_msg}")
        raise ValueError(error_msg)

def load_and_clean_data(file_path):
    """
    Load CSV and perform initial data cleaning with smart column standardization.
    
    Features:
    - Automatically detects and renames common column name variations
    - Case-insensitive column matching
    - Friendly error messages for missing required columns
    - Data validation and cleaning
    
    Parameters:
    - file_path: Path to CSV file
    
    Returns:
    - Cleaned DataFrame with standard column names
    
    Raises:
    - ValueError: If required columns cannot be found
    - Exception: If file loading fails
    """
    try:
        # Load CSV file
        df = pd.read_csv(file_path)
        logger.info(f"[DATA] Loaded {len(df)} rows from {file_path}")
        logger.info(f"[DATA] Original columns: {list(df.columns)}")
        
        # STEP 1: Standardize column names
        logger.info("[DATA] 🔄 Standardizing column names...")
        df, applied_mappings = standardize_column_names(df)
        
        if applied_mappings:
            logger.info(f"[DATA] ✅ Applied {len(applied_mappings)} column mappings: {applied_mappings}")
        else:
            logger.info("[DATA] ℹ️  All columns already use standard names")
        
        # STEP 2: Validate required columns exist
        logger.info("[DATA] 🔍 Validating required columns...")
        validate_required_columns(df)
        logger.info("[DATA] ✅ All required columns present")
        
        # STEP 3: Add optional columns if missing
        if 'Description' not in df.columns:
            df['Description'] = 'Product'
            logger.info("[DATA] ℹ️  Added default 'Description' column")
        
        if 'InvoiceNo' not in df.columns:
            df['InvoiceNo'] = range(len(df))
            logger.info("[DATA] ℹ️  Added auto-generated 'InvoiceNo' column")
        
        # STEP 4: Parse and clean data
        logger.info("[DATA] 🧹 Cleaning data...")
        
        # Parse date
        df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], errors='coerce')
        
        # Remove rows with invalid dates
        initial_rows = len(df)
        df = df.dropna(subset=['CustomerID', 'InvoiceDate', 'Quantity', 'UnitPrice'])
        rows_removed_invalid = initial_rows - len(df)
        if rows_removed_invalid > 0:
            logger.info(f"[DATA] Removed {rows_removed_invalid} rows with invalid/missing data")
        
        # Remove rows with non-positive quantity or price
        initial_rows = len(df)
        df = df[(df['Quantity'] > 0) & (df['UnitPrice'] > 0)]
        rows_removed_invalid_values = initial_rows - len(df)
        if rows_removed_invalid_values > 0:
            logger.info(f"[DATA] Removed {rows_removed_invalid_values} rows with non-positive Quantity or UnitPrice")
        
        # Ensure CustomerID is not null
        df = df[df['CustomerID'].notna()]
        
        # Calculate amount (in case it doesn't exist)
        if 'Amount' not in df.columns:
            df['Amount'] = df['Quantity'] * df['UnitPrice']
            logger.info("[DATA] ℹ️  Calculated 'Amount' column from Quantity × UnitPrice")
        
        logger.info(f"[DATA] ✅ Final cleaned data: {len(df)} rows")
        logger.info(f"[DATA] Final columns: {list(df.columns)}")
        
        return df
        
    except ValueError as ve:
        # Re-raise ValueError (validation error with friendly message)
        logger.error(f"[DATA] Validation error: {ve}")
        raise
    except Exception as e:
        logger.error(f"[DATA] Error loading data: {e}", exc_info=True)
        raise ValueError(f"Failed to load file: {str(e)}")

def compute_rfm_with_log_transform(df, snapshot_date=None):
    """
    Compute RFM metrics with log transformation for Monetary values.
    
    Recency: Days since last purchase
    Frequency: Number of purchases (log-transformed)
    Monetary: Total spending (log-transformed)
    """
    try:
        if snapshot_date is None:
            snapshot_date = df['InvoiceDate'].max() + timedelta(days=1)
        
        # Determine invoice column name
        invoice_col = 'InvoiceNo' if 'InvoiceNo' in df.columns else 'InvoiceID'
        
        # Group by customer
        rfm = df.groupby('CustomerID').agg({
            'InvoiceDate': lambda x: (snapshot_date - x.max()).days,
            invoice_col: 'count',
            'Amount': 'sum'
        }).reset_index()
        
        rfm.columns = ['CustomerID', 'Recency', 'Frequency', 'Monetary']
        
        # Apply log transformation to avoid skewness
        # Log(Frequency + 1) to handle customers with frequency=1
        rfm['Frequency_log'] = np.log1p(rfm['Frequency'])
        rfm['Monetary_log'] = np.log1p(rfm['Monetary'])
        
        logger.info(f"[RFM] Computed RFM for {len(rfm)} customers")
        logger.info(f"[RFM] Recency range: {rfm['Recency'].min()}-{rfm['Recency'].max()}")
        logger.info(f"[RFM] Frequency range: {rfm['Frequency'].min()}-{rfm['Frequency'].max()}")
        logger.info(f"[RFM] Monetary range: ${rfm['Monetary'].min():.2f}-${rfm['Monetary'].max():.2f}")
        
        return rfm
    except Exception as e:
        logger.error(f"[RFM] Error computing RFM: {e}")
        raise

def scale_rfm_features(rfm):
    """Apply MinMax scaling to RFM features for K-means."""
    try:
        scaler = MinMaxScaler(feature_range=(0, 1))
        
        # Use log-transformed features for scaling
        rfm_features = rfm[['Recency', 'Frequency_log', 'Monetary_log']].values
        rfm_scaled = scaler.fit_transform(rfm_features)
        
        # Create scaled dataframe
        rfm_scaled_df = pd.DataFrame(
            rfm_scaled,
            columns=['Recency_scaled', 'Frequency_scaled', 'Monetary_scaled']
        )
        
        rfm = pd.concat([rfm, rfm_scaled_df], axis=1)
        
        logger.info("[SCALE] MinMax scaling applied: [0, 1]")
        return rfm, scaler
    except Exception as e:
        logger.error(f"[SCALE] Error scaling RFM: {e}")
        raise

def perform_kmeans_clustering(rfm, n_clusters=4):
    """
    Perform K-means clustering on scaled RFM data.
    Maps clusters to meaningful segment names.
    """
    try:
        # Prepare scaled features
        rfm_features_scaled = rfm[['Recency_scaled', 'Frequency_scaled', 'Monetary_scaled']].values
        
        # Fit K-means
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        rfm['Cluster'] = kmeans.fit_predict(rfm_features_scaled)
        
        # 📊 Calculate WCSS (Within-Cluster Sum of Squares) - Inertia
        wcss = kmeans.inertia_
        
        # 📊 Calculate Silhouette Score (measures cluster cohesion and separation)
        silhouette_avg = silhouette_score(rfm_features_scaled, rfm['Cluster'])
        
        # 🔍 Log model evaluation metrics
        logger.info(f"[KMEANS] ===============================================")
        logger.info(f"[KMEANS] K-means Model Evaluation Metrics (k={n_clusters})")
        logger.info(f"[KMEANS] ===============================================")
        logger.info(f"[KMEANS] WCSS (Inertia): {wcss:.4f}")
        logger.info(f"[KMEANS]   → Lower WCSS indicates tighter clustering")
        logger.info(f"[KMEANS]   → This value validates the Elbow Method analysis")
        logger.info(f"[KMEANS] ")
        logger.info(f"[KMEANS] Silhouette Score: {silhouette_avg:.4f}")
        logger.info(f"[KMEANS]   → Range: [-1, 1]  (Higher is better)")
        logger.info(f"[KMEANS]   → {silhouette_avg:.4f} indicates {'Strong' if silhouette_avg > 0.5 else 'Moderate' if silhouette_avg > 0.3 else 'Weak'} cluster cohesion")
        logger.info(f"[KMEANS]   → This validates the Silhouette Analysis")
        logger.info(f"[KMEANS] ===============================================")
        
        # Calculate cluster statistics
        cluster_stats = rfm.groupby('Cluster').agg({
            'Recency': ['mean', 'median'],
            'Frequency': ['mean', 'median'],
            'Monetary': ['mean', 'median'],
            'CustomerID': 'count'
        }).round(2)
        
        logger.info(f"[KMEANS] K-means clustering with k={n_clusters} completed")
        logger.info(f"[KMEANS] Cluster centers:\n{kmeans.cluster_centers_}")
        logger.info(f"[KMEANS] Cluster sizes:\n{rfm['Cluster'].value_counts().sort_index()}")
        
        # Map clusters to segment names based on Monetary & Frequency
        cluster_to_segment = map_clusters_to_segments(rfm, kmeans.cluster_centers_)
        rfm['Segment'] = rfm['Cluster'].map(cluster_to_segment)
        
        logger.info(f"[KMEANS] Segment mapping: {cluster_to_segment}")
        
        return rfm, kmeans, cluster_stats
    except Exception as e:
        logger.error(f"[KMEANS] Error in clustering: {e}")
        raise

def map_clusters_to_segments(rfm, cluster_centers):
    """
    Map clusters to meaningful customer segments based on Monetary and Frequency.
    
    Cluster centers format: [Recency_scaled, Frequency_scaled, Monetary_scaled]
    Handles cases where not all 4 clusters are present in the data.
    """
    # Get unique clusters present in the data
    unique_clusters = sorted(rfm['Cluster'].unique())
    
    # Calculate monetary value for each cluster
    cluster_monetary_score = {}
    for cluster_id in unique_clusters:
        cluster_data = rfm[rfm['Cluster'] == cluster_id]
        avg_monetary = cluster_data['Monetary'].mean()
        avg_frequency = cluster_data['Frequency'].mean()
        cluster_monetary_score[cluster_id] = (avg_monetary, avg_frequency)
    
    # Sort clusters by monetary value
    sorted_clusters = sorted(cluster_monetary_score.items(), key=lambda x: x[1][0], reverse=True)
    
    # Assign segment names based on number of clusters present
    segment_names = {}
    
    if len(sorted_clusters) == 1:
        # Only 1 cluster - all customers in one group
        segment_names[sorted_clusters[0][0]] = 'High Value'
    elif len(sorted_clusters) == 2:
        # 2 clusters
        segment_names[sorted_clusters[0][0]] = 'High Value'
        segment_names[sorted_clusters[1][0]] = 'Low Value'
    elif len(sorted_clusters) == 3:
        # 3 clusters
        segment_names[sorted_clusters[0][0]] = 'High Value'
        segment_names[sorted_clusters[1][0]] = 'Mid Value'
        segment_names[sorted_clusters[2][0]] = 'Low Value'
    else:
        # 4+ clusters (standard case)
        segment_names[sorted_clusters[0][0]] = 'High Value'      # Highest spending
        segment_names[sorted_clusters[1][0]] = 'Mid Value'       # Mid spending
        segment_names[sorted_clusters[2][0]] = 'Low Value'       # Low spending
        segment_names[sorted_clusters[3][0]] = 'At Risk'         # Lowest spending or high recency
    
    logger.info(f"[KMEANS] Cluster count: {len(sorted_clusters)}")
    logger.info(f"[KMEANS] Segment mapping: {segment_names}")
    
    return segment_names

def calculate_churn_rate(rfm, days_threshold=30):
    """
    Calculate churn rate as percentage of customers inactive for > days_threshold.
    
    Parameters:
    - rfm: RFM dataframe with Recency column
    - days_threshold: Days without purchase to be considered churned (default: 30)
    
    Returns:
    - Tuple: (churn_rate_pct, churned_count, total_count)
    """
    try:
        total_customers = len(rfm)
        churned_customers = len(rfm[rfm['Recency'] > days_threshold])
        churn_rate = (churned_customers / total_customers * 100) if total_customers > 0 else 0
        
        logger.info(f"[CHURN] Churn Rate ({days_threshold}+ days): {churn_rate:.1f}% ({churned_customers}/{total_customers})")
        
        return churn_rate, churned_customers, total_customers
    except Exception as e:
        logger.error(f"[CHURN] Error calculating churn rate: {e}")
        raise

def get_active_customers_count(rfm, days_threshold=30):
    """
    Get count of active customers (purchased within last days_threshold days).
    """
    try:
        active_count = len(rfm[rfm['Recency'] <= days_threshold])
        logger.info(f"[ACTIVE] Active customers (within {days_threshold} days): {active_count}")
        return active_count
    except Exception as e:
        logger.error(f"[ACTIVE] Error getting active customers: {e}")
        raise

def prepare_cluster_profile_data(rfm):
    """
    Prepare cluster profile data for radar chart.
    Calculates mean R, F, M for each cluster.
    
    Returns:
    - DataFrame with cluster-wise statistics
    """
    try:
        cluster_stats = rfm.groupby('Segment').agg({
            'Recency': 'mean',
            'Frequency': 'mean',
            'Monetary': 'mean',
            'CustomerID': 'count'
        }).reset_index()
        
        cluster_stats.columns = ['Segment', 'Avg_Recency', 'Avg_Frequency', 'Avg_Monetary', 'Customer_Count']
        
        # Normalize for radar chart (0-100 scale)
        max_recency = cluster_stats['Avg_Recency'].max()
        max_frequency = cluster_stats['Avg_Frequency'].max()
        max_monetary = cluster_stats['Avg_Monetary'].max()
        
        cluster_stats['Recency_Score'] = (1 - cluster_stats['Avg_Recency'] / max_recency) * 100 if max_recency > 0 else 0
        cluster_stats['Frequency_Score'] = (cluster_stats['Avg_Frequency'] / max_frequency) * 100 if max_frequency > 0 else 0
        cluster_stats['Monetary_Score'] = (cluster_stats['Avg_Monetary'] / max_monetary) * 100 if max_monetary > 0 else 0
        
        logger.info(f"[CLUSTER_PROFILE] Prepared profile data for {len(cluster_stats)} segments")
        
        return cluster_stats
    except Exception as e:
        logger.error(f"[CLUSTER_PROFILE] Error preparing cluster profile data: {e}")
        raise

def prepare_sales_heatmap_data(df):
    """
    Prepare sales heatmap data: Orders by Day of Week (0-6: Mon-Sun) and Hour (0-23).
    
    Returns:
    - 2D numpy array of shape (7, 24) representing weekly hourly sales
    """
    try:
        # Extract day of week and hour
        df['DayOfWeek'] = df['InvoiceDate'].dt.dayofweek
        df['Hour'] = df['InvoiceDate'].dt.hour
        
        # Create heatmap data
        heatmap_data = df.groupby(['DayOfWeek', 'Hour']).size().reset_index(name='Order_Count')
        
        # Create 7x24 matrix
        heatmap_matrix = np.zeros((7, 24))
        for _, row in heatmap_data.iterrows():
            heatmap_matrix[int(row['DayOfWeek']), int(row['Hour'])] = row['Order_Count']
        
        logger.info(f"[HEATMAP] Sales heatmap data prepared (7 days x 24 hours)")
        
        return heatmap_matrix
    except Exception as e:
        logger.error(f"[HEATMAP] Error preparing heatmap data: {e}")
        raise

def prepare_monthly_sales_trend(df):
    """
    Prepare monthly sales trend data.
    
    Returns:
    - DataFrame with monthly revenue and customer count
    """
    try:
        # Extract year-month
        df['YearMonth'] = df['InvoiceDate'].dt.to_period('M')
        
        # Group by month
        monthly_trend = df.groupby('YearMonth').agg({
            'Amount': 'sum',
            'CustomerID': 'nunique',
            'InvoiceNo' if 'InvoiceNo' in df.columns else 'InvoiceID': 'count'
        }).reset_index()
        
        monthly_trend.columns = ['Month', 'Total_Revenue', 'Unique_Customers', 'Total_Orders']
        monthly_trend['Month'] = monthly_trend['Month'].astype(str)
        monthly_trend = monthly_trend.sort_values('Month')
        
        logger.info(f"[MONTHLY] Monthly sales trend prepared for {len(monthly_trend)} months")
        
        return monthly_trend
    except Exception as e:
        logger.error(f"[MONTHLY] Error preparing monthly sales trend: {e}")
        raise

def prepare_top_products(df, n=10):
    """
    Get top N products by quantity sold.
    
    Returns:
    - DataFrame with product info, quantity, and revenue
    """
    try:
        product_sales = df.groupby('Description').agg({
            'Quantity': 'sum',
            'Amount': 'sum'
        }).reset_index()
        
        product_sales.columns = ['Product', 'Total_Quantity', 'Total_Revenue']
        product_sales = product_sales.sort_values('Total_Quantity', ascending=False).head(n)
        
        logger.info(f"[TOP_PRODUCTS] Top {n} products prepared")
        
        return product_sales
    except Exception as e:
        logger.error(f"[TOP_PRODUCTS] Error preparing top products: {e}")
        raise

def prepare_pareto_analysis(df):
    """
    Prepare data for Pareto analysis (Product Portfolio Analysis).
    
    Returns a DataFrame with:
    - Product description
    - Total revenue
    - Cumulative percentage of total revenue
    """
    try:
        # Group by product and calculate total revenue
        product_revenue = df.groupby('Description').agg({
            'Amount': 'sum',
            'Quantity': 'sum'
        }).reset_index()
        
        # Sort by revenue descending
        product_revenue = product_revenue.sort_values('Amount', ascending=False).reset_index(drop=True)
        
        # Calculate cumulative revenue and percentage
        total_revenue = product_revenue['Amount'].sum()
        product_revenue['Cumulative_Amount'] = product_revenue['Amount'].cumsum()
        product_revenue['Cumulative_Percentage'] = (product_revenue['Cumulative_Amount'] / total_revenue * 100).round(2)
        product_revenue['Percentage'] = (product_revenue['Amount'] / total_revenue * 100).round(2)
        
        # Rank products
        product_revenue['Rank'] = range(1, len(product_revenue) + 1)
        
        logger.info(f"[PARETO] Prepared Pareto analysis for {len(product_revenue)} products")
        logger.info(f"[PARETO] Top 20% products: {len(product_revenue[product_revenue['Cumulative_Percentage'] <= 80])} products")
        
        return product_revenue
    except Exception as e:
        logger.error(f"[PARETO] Error preparing Pareto analysis: {e}")
        raise