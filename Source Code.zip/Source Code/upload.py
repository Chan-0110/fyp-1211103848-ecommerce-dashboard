"""
Upload Dataset Module (Redesigned)
Handles data upload page with new data processing pipeline
"""

import base64
import io
import logging
import json
from dash import html, dcc, Input, Output, State
import pandas as pd

from data_processing import (
    load_and_clean_data,
    compute_rfm_with_log_transform,
    scale_rfm_features,
    perform_kmeans_clustering,
    standardize_column_names
)

logger = logging.getLogger(__name__)

# 📦 Global cache for uploaded data (to bypass sessionStorage quota limit)
_uploaded_data_cache = {}


# =============================================
# UPLOAD PAGE RENDERING
# =============================================

def render_upload_page():
    """Render standalone data upload page."""
    return html.Div([
        html.Div([
            html.Div([
                html.H1('📊 E-Commerce RFM Analytics', style={'color': 'white', 'marginBottom': '10px', 'marginTop': '0', 'fontSize': '28px'}),
            ], style={'display': 'inline-block', 'width': '85%', 'verticalAlign': 'middle'}),
            
            html.Button('Logout', id='logout-btn-upload', n_clicks=0, style={
                'padding': '10px 20px',
                'backgroundColor': '#ff6b6b',
                'color': 'white',
                'border': 'none',
                'borderRadius': '4px',
                'cursor': 'pointer',
                'fontSize': '14px',
                'fontWeight': 'bold',
                'display': 'inline-block',
                'verticalAlign': 'middle',
                'float': 'right',
                'marginTop': '10px'
            })
        ], style={
            'background': 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            'padding': '20px',
            'color': 'white',
            'marginBottom': '20px',
            'borderRadius': '0',
            'overflow': 'auto'
        }),
        
        html.Div([
            html.Div([
                html.H2('📤 Upload Your Dataset', style={'color': '#667eea', 'marginTop': '0', 'marginBottom': '20px', 'fontSize': '24px', 'textAlign': 'center'}),
                html.P('Supported Columns (Auto-Detected): CustomerID, InvoiceDate, Quantity, UnitPrice, Description | Accepts common variants (e.g., Price, Date, Qty)', 
                      style={'textAlign': 'center', 'color': '#666', 'marginBottom': '30px', 'fontSize': '13px'}),
                
                dcc.Upload(
                    id='upload-data-page',
                    children=html.Div([
                        '📁 Drag and drop or ',
                        html.A('click to select'),
                        html.Br(),
                        'CSV or Excel file (.csv, .xlsx, .xls)'
                    ], style={'fontSize': '16px', 'fontWeight': '500', 'color': '#667eea'}),
                    style={
                        'width': '90%', 'height': '200px', 'borderWidth': '2px', 'borderStyle': 'dashed',
                        'borderRadius': '8px', 'textAlign': 'center', 'borderColor': '#667eea',
                        'backgroundColor': '#f0f4ff', 'cursor': 'pointer', 'padding': '30px',
                        'display': 'flex', 'alignItems': 'center', 'justifyContent': 'center', 'boxSizing': 'border-box',
                        'margin': '0 auto'
                    },
                    multiple=False
                ),
                
                html.Div(id='upload-page-status', style={
                    'marginTop': '20px', 'color': '#666', 'fontSize': '14px', 'textAlign': 'center',
                    'minHeight': '30px', 'fontWeight': '500'
                }),
                
                html.Div(id='upload-progress', style={
                    'marginTop': '20px',
                    'padding': '15px',
                    'backgroundColor': '#f0f4ff',
                    'borderRadius': '4px',
                    'fontSize': '13px',
                    'color': '#667eea',
                    'display': 'none'
                }),
                
            ], style={
                'width': '700px', 'margin': '60px auto', 'padding': '40px',
                'backgroundColor': 'white', 'borderRadius': '8px', 'boxShadow': '0 4px 15px rgba(0,0,0,0.1)'
            })
        ], style={'backgroundColor': '#f5f5f5', 'minHeight': '100vh', 'paddingTop': '20px'})
    ])

# =============================================
# CALLBACK FUNCTIONS
# =============================================

def register_upload_callbacks(app):
    """Register upload callbacks."""
    
    @app.callback(
        Output('data-uploaded-store', 'data'),
        Output('data-store', 'data'),
        Output('upload-page-status', 'children'),
        Output('upload-progress', 'children'),
        Output('upload-progress', 'style'),
        Input('upload-data-page', 'contents'),
        State('upload-data-page', 'filename'),
        prevent_initial_call=True
    )
    def handle_upload_page(contents, filename):
        """Handle file upload with complete data processing pipeline."""
        try:
            if not contents or not filename:
                return (
                    {'uploaded': False, 'filename': '', 'row_count': 0},
                    {'tx_count': 0, 'rfm_count': 0, 'tx_json': None, 'rfm_json': None},
                    '❌ No file selected',
                    '',
                    {'display': 'none'}
                )
            
            logger.info(f"[UPLOAD] Processing file: {filename}")
            
            # Decode file
            content_type, content_string = contents.split(',')
            decoded = base64.b64decode(content_string)
            
            # Load and clean data
            logger.info("[UPLOAD] 🔄 Loading and cleaning data...")
            
            # Support both CSV and Excel files
            if filename.endswith('.csv'):
                df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))
            elif filename.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(io.BytesIO(decoded))
            else:
                raise ValueError("File must be CSV or Excel format (.csv, .xlsx, .xls)")
            
            logger.info(f"[UPLOAD] Raw data: {len(df)} rows")
            
            # ✅ CHANGE 1: Standardize column names for flexible input
            logger.info("[UPLOAD] 🔧 Standardizing column names...")
            df, applied_mappings = standardize_column_names(df)
            if applied_mappings:
                logger.info(f"[UPLOAD] Applied mappings: {applied_mappings}")
            
            # ⚠️ Data sampling: Limit to 50,000 rows for performance
            if len(df) > 50000:
                logger.info(f"[UPLOAD] 📊 Dataset exceeds 50,000 rows. Performing stratified sampling...")
                df = df.sample(n=50000, random_state=42)
                logger.info(f"[UPLOAD] ✅ Sampled to 50,000 rows (representative sample)")
            
            # Validate required columns
            required_cols = ['CustomerID', 'InvoiceDate', 'Quantity', 'UnitPrice']
            missing_cols = [col for col in required_cols if col not in df.columns]
            
            # Add Description column if not present
            if 'Description' not in df.columns:
                df['Description'] = 'Product'
            
            if missing_cols:
                error_msg = f"❌ Missing columns: {', '.join(missing_cols)}"
                logger.error(f"[UPLOAD] {error_msg}")
                return (
                    {'uploaded': False, 'filename': '', 'row_count': 0},
                    {'tx_count': 0, 'rfm_count': 0, 'tx_json': None, 'rfm_json': None},
                    error_msg,
                    f"❌ Error: {error_msg}",
                    {'display': 'block', 'marginTop': '20px', 'padding': '15px', 
                     'backgroundColor': '#ffe0e0', 'borderRadius': '4px', 'fontSize': '13px', 
                     'color': '#cc0000'}
                )
            
            # Clean data
            df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], errors='coerce')
            df = df.dropna(subset=['CustomerID', 'InvoiceDate', 'Quantity', 'UnitPrice'])
            df = df[(df['Quantity'] > 0) & (df['UnitPrice'] > 0)]
            df['Amount'] = df['Quantity'] * df['UnitPrice']
            logger.info(f"[UPLOAD] After cleaning: {len(df)} rows")
            
            # Compute RFM with log transformation
            logger.info("[UPLOAD] 📊 Computing RFM metrics with log transformation...")
            rfm = compute_rfm_with_log_transform(df)
            
            # Scale features
            logger.info("[UPLOAD] ⚖️ Scaling features (MinMax)...")
            rfm, scaler = scale_rfm_features(rfm)
            
            # Perform K-means clustering
            logger.info("[UPLOAD] 🎯 Clustering customers (K-means, k=4)...")
            rfm, kmeans, cluster_stats = perform_kmeans_clustering(rfm, n_clusters=4)
            
            logger.info(f"[UPLOAD] RFM final: {len(rfm)} customers with segments")
            
            # Prepare data for storage (convert to JSON)
            # ✅ CRITICAL FIX: Add 'Country' column to transaction data
            df['Country'] = df['Country'].astype(str)  # Ensure Country is treated as string
            tx_json = df[['CustomerID', 'InvoiceDate', 'Amount', 'Quantity', 'UnitPrice', 'Description', 'Country']].to_json(orient='records', date_format='iso')
            rfm_json = rfm[['CustomerID', 'Recency', 'Frequency', 'Monetary', 'Frequency_log', 
                            'Monetary_log', 'Cluster', 'Segment']].to_json(orient='records')
            
            # 📦 Cache data in memory to avoid sessionStorage quota issues
            global _uploaded_data_cache
            _uploaded_data_cache = {
                'tx_json': tx_json,
                'rfm_json': rfm_json
            }
            logger.info("[UPLOAD] ✅ Data cached in memory")
            
            # Success status
            status_msg = f"""✅ Upload successful!
            📊 {len(df):,} transactions processed
            👥 {len(rfm):,} unique customers
            🎯 4 customer segments created"""
            
            progress_msg_final = f"""✅ Data processing complete!
            • Rows: {len(df):,}
            • Customers: {len(rfm):,}
            • Segments: High Value, Mid Value, Low Value, At Risk
            • Redirecting to dashboard in 3 seconds...
            """
            
            logger.info("[UPLOAD] Processing completed successfully")
            
            return (
                {'uploaded': True, 'filename': filename, 'row_count': len(df)},
                {'tx_count': len(df), 'rfm_count': len(rfm), 'tx_json': tx_json, 'rfm_json': rfm_json},
                status_msg,
                progress_msg_final,
                {'display': 'block', 'marginTop': '20px', 'padding': '15px', 
                 'backgroundColor': '#e0ffe0', 'borderRadius': '4px', 'fontSize': '13px', 
                 'color': '#008000'}
            )
            
        except Exception as e:
            error_msg = f"❌ Error processing file: {str(e)}"
            logger.error(f"[UPLOAD] {error_msg}", exc_info=True)
            
            return (
                {'uploaded': False, 'filename': '', 'row_count': 0},
                {'tx_count': 0, 'rfm_count': 0, 'tx_json': None, 'rfm_json': None},
                error_msg,
                f"❌ Error: {error_msg}",
                {'display': 'block', 'marginTop': '20px', 'padding': '15px', 
                 'backgroundColor': '#ffe0e0', 'borderRadius': '4px', 'fontSize': '13px', 
                 'color': '#cc0000'}
            )

    @app.callback(
        Output('login-store', 'data', allow_duplicate=True),
        Input('logout-btn-upload', 'n_clicks'),
        State('login-store', 'data'),
        prevent_initial_call=True
    )
    def handle_logout_upload(n_clicks, login_data):
        """Handle logout from upload page."""
        logger.info(f"[LOGOUT_UPLOAD] n_clicks={n_clicks}")
        if n_clicks and n_clicks > 0:
            logger.info("[LOGOUT_UPLOAD] User logged out")
            return {'logged_in': False, 'username': '', 'show_register': False}
        return login_data
